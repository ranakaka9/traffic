import { DeviceProfile, TrafficPattern } from '../lib/simulation-engine';

export type { DeviceProfile, TrafficPattern };

export type WorkerEngineType = 'go_http' | 'playwright_browser';
export type ProxyType = 'datacenter' | 'residential' | 'mobile';

export interface ProxyRegionConfig {
  id: string;
  name: string;
  code: string;
  flag: string;
  datacenterLatMs: number;
  residentialLatMs: number;
  mobileLatMs: number;
  availableIps: number;
  selected: boolean;
  weightPct: number;
}

export interface ScenarioConfig {
  id: string;
  name: string;
  targetUrl: string;
  workerType: WorkerEngineType;
  pattern: TrafficPattern;
  peakConcurrency: number;
  durationSeconds: number;
  rampUpSeconds: number;
  bounceRatePct: number;
  scrollDepthPct: number;
  proxyType: ProxyType;
  regions: ProxyRegionConfig[];
  deviceMix: Array<{
    profileId: string;
    weightPct: number;
  }>;
  safetyKillOn5xxPct: number;
  safetyMaxRps: number;
  respectRobotsTxt: boolean;
}

export interface SimulationTelemetry {
  elapsedSeconds: number;
  activeVUs: number;
  currentRps: number;
  totalRequests: number;
  statusCodes: {
    '200': number;
    '304': number;
    '429': number;
    '500': number;
    '503': number;
  };
  latency: {
    p50: number;
    p95: number;
    p99: number;
    avg: number;
  };
  cdnCache: {
    hitRatio: number;
    hits: number;
    misses: number;
  };
  bandwidthMbps: number;
  activeWorkers: number;
  isKilled: boolean;
  killReason?: string;
  logs: SimulationLogEntry[];
}

export interface SimulationLogEntry {
  id: string;
  timestamp: string;
  region: string;
  workerId: string;
  device: string;
  ip: string;
  method: string;
  path: string;
  status: number;
  ttfbMs: number;
  cacheStatus: 'HIT' | 'MISS' | 'BYPASS';
}

export interface VerifiedDomain {
  domain: string;
  token: string;
  verified: boolean;
  verificationMethod: 'dns_txt' | 'html_meta';
  verifiedAt?: string;
  robotsTxtSnippet: string;
  crawlDelay: number | null;
  disallowedPaths: string[];
}

export type SaaSPlanTier = 'free' | 'pro' | 'enterprise';

export interface SaaSUser {
  id: string;
  name: string;
  organization: string;
  tier: SaaSPlanTier;
  creditsRemaining: number;
  maxConcurrency: number;
  allowedProxies: ProxyType[];
  apiRateLimitRpm: number;
}
