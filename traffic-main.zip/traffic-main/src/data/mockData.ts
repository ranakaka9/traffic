import { DeviceProfile, ProxyRegionConfig, ScenarioConfig, SaaSUser } from '../types';

export const DEVICE_PROFILES: DeviceProfile[] = [
  {
    id: 'win11-chrome',
    name: 'Windows 11 (Chrome 128)',
    category: 'desktop',
    os: 'Windows 11',
    browser: 'Chrome 128',
    viewport: { width: 1920, height: 1080, dpr: 1 },
    touch: false,
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    clientHints: {
      mobile: false,
      platform: 'Windows',
      brands: [
        { brand: 'Chromium', version: '128' },
        { brand: 'Google Chrome', version: '128' },
        { brand: 'Not;A=Brand', version: '24' },
      ],
    },
  },
  {
    id: 'win11-edge',
    name: 'Windows 11 (MS Edge 128)',
    category: 'desktop',
    os: 'Windows 11',
    browser: 'Edge 128',
    viewport: { width: 1920, height: 1080, dpr: 1 },
    touch: false,
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
    clientHints: {
      mobile: false,
      platform: 'Windows',
      brands: [
        { brand: 'Chromium', version: '128' },
        { brand: 'Microsoft Edge', version: '128' },
        { brand: 'Not;A=Brand', version: '24' },
      ],
    },
  },
  {
    id: 'win10-firefox',
    name: 'Windows 10 (Firefox 130)',
    category: 'desktop',
    os: 'Windows 10',
    browser: 'Firefox 130',
    viewport: { width: 1440, height: 900, dpr: 1 },
    touch: false,
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0',
    clientHints: {
      mobile: false,
      platform: 'Windows',
      brands: [{ brand: 'Firefox', version: '130' }],
    },
  },
  {
    id: 'ios18-safari',
    name: 'iPhone 16 Pro (iOS 18 Safari)',
    category: 'mobile',
    os: 'iOS 18',
    browser: 'Safari 18',
    viewport: { width: 393, height: 852, dpr: 3 },
    touch: true,
    userAgent:
      'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1',
    clientHints: {
      mobile: true,
      platform: 'iOS',
      brands: [{ brand: 'Safari', version: '18' }],
    },
  },
  {
    id: 'android15-chrome',
    name: 'Pixel 9 Pro (Android 15 Chrome)',
    category: 'mobile',
    os: 'Android 15',
    browser: 'Chrome 128',
    viewport: { width: 412, height: 915, dpr: 2.625 },
    touch: true,
    userAgent:
      'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Mobile Safari/537.36',
    clientHints: {
      mobile: true,
      platform: 'Android',
      brands: [
        { brand: 'Chromium', version: '128' },
        { brand: 'Google Chrome', version: '128' },
      ],
    },
  },
  {
    id: 'ipados18-safari',
    name: 'iPad Pro 13" (iPadOS 18 Safari)',
    category: 'tablet',
    os: 'iPadOS 18',
    browser: 'Safari 18',
    viewport: { width: 1024, height: 1366, dpr: 2 },
    touch: true,
    userAgent:
      'Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1',
    clientHints: {
      mobile: false,
      platform: 'macOS', // Safari on iPadOS sends macOS platform header
      brands: [{ brand: 'Safari', version: '18' }],
    },
  },
];

export const PROXY_REGIONS: ProxyRegionConfig[] = [
  {
    id: 'us-east',
    name: 'North America (US-East)',
    code: 'US-VA',
    flag: '🇺🇸',
    datacenterLatMs: 22,
    residentialLatMs: 48,
    mobileLatMs: 72,
    availableIps: 1420000,
    selected: true,
    weightPct: 40,
  },
  {
    id: 'eu-central',
    name: 'Europe (Frankfurt)',
    code: 'EU-DE',
    flag: '🇩🇪',
    datacenterLatMs: 34,
    residentialLatMs: 62,
    mobileLatMs: 88,
    availableIps: 980000,
    selected: true,
    weightPct: 30,
  },
  {
    id: 'ap-east',
    name: 'Asia-Pacific (Tokyo)',
    code: 'AP-JP',
    flag: '🇯🇵',
    datacenterLatMs: 65,
    residentialLatMs: 110,
    mobileLatMs: 135,
    availableIps: 840000,
    selected: true,
    weightPct: 20,
  },
  {
    id: 'sa-east',
    name: 'Latin America (São Paulo)',
    code: 'SA-BR',
    flag: '🇧🇷',
    datacenterLatMs: 115,
    residentialLatMs: 165,
    mobileLatMs: 210,
    availableIps: 320000,
    selected: true,
    weightPct: 10,
  },
];

export const PRESET_SCENARIOS: ScenarioConfig[] = [
  {
    id: 'ecommerce-flash-sale',
    name: 'E-Commerce Black Friday Flash Spike',
    targetUrl: 'https://demo-shop.aetherload.dev/checkout/cart',
    workerType: 'playwright_browser',
    pattern: 'spike',
    peakConcurrency: 1500,
    durationSeconds: 90,
    rampUpSeconds: 20,
    bounceRatePct: 24,
    scrollDepthPct: 75,
    proxyType: 'residential',
    regions: PROXY_REGIONS,
    deviceMix: [
      { profileId: 'win11-chrome', weightPct: 30 },
      { profileId: 'ios18-safari', weightPct: 40 },
      { profileId: 'android15-chrome', weightPct: 25 },
      { profileId: 'ipados18-safari', weightPct: 5 },
    ],
    safetyKillOn5xxPct: 12,
    safetyMaxRps: 5000,
    respectRobotsTxt: true,
  },
  {
    id: 'cdn-cache-warmup',
    name: 'Global CDN Cache-Buster & Warmup',
    targetUrl: 'https://demo-cdn.aetherload.dev/assets/catalog/items.json',
    workerType: 'go_http',
    pattern: 'steady',
    peakConcurrency: 4500,
    durationSeconds: 120,
    rampUpSeconds: 10,
    bounceRatePct: 5,
    scrollDepthPct: 0,
    proxyType: 'datacenter',
    regions: PROXY_REGIONS,
    deviceMix: [
      { profileId: 'win11-chrome', weightPct: 50 },
      { profileId: 'win10-firefox', weightPct: 20 },
      { profileId: 'android15-chrome', weightPct: 30 },
    ],
    safetyKillOn5xxPct: 15,
    safetyMaxRps: 15000,
    respectRobotsTxt: true,
  },
  {
    id: 'mobile-app-launch',
    name: 'Mobile 5G App Launch Stress',
    targetUrl: 'https://api.aetherload.dev/v2/feed/recommendations',
    workerType: 'go_http',
    pattern: 'ramp',
    peakConcurrency: 3000,
    durationSeconds: 60,
    rampUpSeconds: 18,
    bounceRatePct: 15,
    scrollDepthPct: 90,
    proxyType: 'mobile',
    regions: PROXY_REGIONS,
    deviceMix: [
      { profileId: 'ios18-safari', weightPct: 60 },
      { profileId: 'android15-chrome', weightPct: 40 },
    ],
    safetyKillOn5xxPct: 10,
    safetyMaxRps: 8000,
    respectRobotsTxt: true,
  },
];

export const INITIAL_USER: SaaSUser = {
  id: 'usr_enterprise_99',
  name: 'Alex Rivera (Staff Site Reliability Eng)',
  organization: 'Apex Global Networks LLC',
  tier: 'pro',
  creditsRemaining: 485000,
  maxConcurrency: 10000,
  allowedProxies: ['datacenter', 'residential', 'mobile'],
  apiRateLimitRpm: 1200,
};

export const DATABASE_SCHEMA_SQL = `-- ============================================================================
-- AETHERLOAD DATABASE SCHEMA (PostgreSQL 16 + TimescaleDB Extension)
-- Production DDL for Global Synthetic Traffic & Load Simulation Engine
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
-- Enable TimescaleDB for ultra-high-throughput time-series metric ingestion
-- (Or ClickHouse distributed table equivalent)
-- CREATE EXTENSION IF NOT EXISTS timescaledb;

-- 1. USERS & ORGANIZATIONS
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TYPE user_role AS ENUM ('super_admin', 'org_admin', 'engineer', 'auditor');
CREATE TYPE subscription_tier AS ENUM ('free', 'pro', 'enterprise');

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150),
    role user_role NOT NULL DEFAULT 'engineer',
    api_key_hash VARCHAR(64) UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. SUBSCRIPTIONS & METERED BILLING
CREATE TYPE subscription_status AS ENUM ('active', 'past_due', 'canceled', 'trialing');

CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID UNIQUE NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    tier subscription_tier NOT NULL DEFAULT 'free',
    stripe_customer_id VARCHAR(100) UNIQUE,
    stripe_subscription_id VARCHAR(100) UNIQUE,
    status subscription_status NOT NULL DEFAULT 'active',
    max_concurrent_vus INTEGER NOT NULL DEFAULT 50, -- Free: 50, Pro: 10000, Ent: 100000+
    allowed_proxy_types VARCHAR(50)[] NOT NULL DEFAULT '{"datacenter"}',
    monthly_compute_credits BIGINT NOT NULL DEFAULT 10000,
    used_credits_current_cycle BIGINT NOT NULL DEFAULT 0,
    current_period_start TIMESTAMPTZ NOT NULL,
    current_period_end TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. DOMAIN COMPLIANCE & SAFETY GATE
CREATE TYPE verification_method AS ENUM ('dns_txt', 'html_meta');

CREATE TABLE domain_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    domain VARCHAR(255) NOT NULL,
    verification_token VARCHAR(128) NOT NULL,
    verification_method verification_method NOT NULL DEFAULT 'dns_txt',
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verified_at TIMESTAMPTZ,
    robots_txt_disallowed_paths TEXT[] DEFAULT '{}',
    robots_crawl_delay_seconds NUMERIC(4,1),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_org_domain UNIQUE (organization_id, domain)
);

-- 4. DEVICE PROFILES (Desktop, Mobile, Tablet Catalog)
CREATE TABLE device_profiles (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(20) NOT NULL CHECK (category IN ('desktop', 'mobile', 'tablet')),
    os_name VARCHAR(50) NOT NULL,
    browser_name VARCHAR(50) NOT NULL,
    viewport_width INTEGER NOT NULL,
    viewport_height INTEGER NOT NULL,
    device_pixel_ratio NUMERIC(4,2) NOT NULL DEFAULT 1.0,
    touch_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    user_agent TEXT NOT NULL,
    client_hints_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. TRAFFIC SCENARIOS (User-configured load definitions)
CREATE TYPE worker_engine AS ENUM ('go_http', 'playwright_browser');
CREATE TYPE traffic_pattern_type AS ENUM ('ramp', 'steady', 'spike', 'step');

CREATE TABLE traffic_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    target_url TEXT NOT NULL,
    worker_type worker_engine NOT NULL DEFAULT 'go_http',
    pattern traffic_pattern_type NOT NULL DEFAULT 'ramp',
    peak_concurrency_vus INTEGER NOT NULL CHECK (peak_concurrency_vus > 0),
    duration_seconds INTEGER NOT NULL CHECK (duration_seconds >= 10 AND duration_seconds <= 86400),
    ramp_up_seconds INTEGER NOT NULL DEFAULT 30,
    proxy_type VARCHAR(20) NOT NULL DEFAULT 'datacenter',
    target_regions JSONB NOT NULL DEFAULT '[]'::jsonb, -- Array of {region: 'us-east', weight: 40}
    device_mix JSONB NOT NULL DEFAULT '[]'::jsonb,      -- Array of {profile_id: 'win11-chrome', weight: 50}
    behavioral_config JSONB NOT NULL DEFAULT '{
        "scroll_depth_pct": 50,
        "bounce_rate_pct": 20,
        "think_time_min_ms": 500,
        "think_time_max_ms": 3000
    }'::jsonb,
    safety_kill_5xx_threshold_pct NUMERIC(4,1) NOT NULL DEFAULT 15.0,
    respect_robots_txt BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. WORKER JOBS & CLUSTER ORCHESTRATION
CREATE TYPE job_status AS ENUM ('queued', 'provisioning', 'running', 'draining', 'completed', 'killed', 'failed');

CREATE TABLE worker_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scenario_id UUID NOT NULL REFERENCES traffic_scenarios(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    status job_status NOT NULL DEFAULT 'queued',
    assigned_cluster_id VARCHAR(64) NOT NULL, -- E.g. k8s-eu-central-pool-01
    active_worker_pods INTEGER NOT NULL DEFAULT 0,
    total_requests_dispatched BIGINT NOT NULL DEFAULT 0,
    total_successful_2xx_3xx BIGINT NOT NULL DEFAULT 0,
    total_client_errors_4xx BIGINT NOT NULL DEFAULT 0,
    total_server_errors_5xx BIGINT NOT NULL DEFAULT 0,
    avg_ttfb_ms NUMERIC(7,2) DEFAULT 0,
    p95_ttfb_ms NUMERIC(7,2) DEFAULT 0,
    p99_ttfb_ms NUMERIC(7,2) DEFAULT 0,
    bandwidth_consumed_bytes BIGINT NOT NULL DEFAULT 0,
    credits_billed BIGINT NOT NULL DEFAULT 0,
    kill_reason TEXT,
    started_at TIMESTAMPTZ,
    ended_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. USAGE METRICS (High-Throughput Time-Series Ingestion)
-- In TimescaleDB: converted to hypertable via SELECT create_hypertable('usage_metrics', 'timestamp');
-- In ClickHouse: ENGINE = MergeTree() PARTITION BY toYYYYMM(timestamp) ORDER BY (scenario_id, timestamp)
CREATE TABLE usage_metrics (
    id UUID DEFAULT gen_random_uuid(),
    job_id UUID NOT NULL REFERENCES worker_jobs(id) ON DELETE CASCADE,
    scenario_id UUID NOT NULL REFERENCES traffic_scenarios(id) ON DELETE CASCADE,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    active_vus INTEGER NOT NULL,
    instantaneous_rps INTEGER NOT NULL,
    success_count_interval INTEGER NOT NULL,
    error_429_count_interval INTEGER NOT NULL,
    error_5xx_count_interval INTEGER NOT NULL,
    avg_ttfb_ms NUMERIC(6,2) NOT NULL,
    p95_ttfb_ms NUMERIC(6,2) NOT NULL,
    p99_ttfb_ms NUMERIC(6,2) NOT NULL,
    cdn_cache_hit_ratio NUMERIC(4,3) NOT NULL, -- 0.000 to 1.000
    bandwidth_mbps NUMERIC(7,2) NOT NULL,
    PRIMARY KEY (id, timestamp)
);

-- INDEXING STRATEGY FOR LOW-LATENCY DASHBOARDS
CREATE INDEX idx_worker_jobs_org_status ON worker_jobs(organization_id, status);
CREATE INDEX idx_usage_metrics_job_time ON usage_metrics(job_id, timestamp DESC);
CREATE INDEX idx_usage_metrics_scenario_time ON usage_metrics(scenario_id, timestamp DESC);
CREATE INDEX idx_domain_verifications_org ON domain_verifications(organization_id);
`;

export const PLAYWRIGHT_WORKER_CODE = `/**
 * ============================================================================
 * AETHERLOAD PLAYWRIGHT WORKER ENGINE (Distributed DOM & Browser Cluster)
 * Production-ready TypeScript implementation for full DOM navigation,
 * real user interactions, client hints spoofing, and proxy egress routing.
 * ============================================================================
 */

import { chromium, BrowserContext, Page, Response } from 'playwright';

export interface WorkerTaskConfig {
  workerId: string;
  targetUrl: string;
  proxyUrl: string;       // e.g. "socks5://pool-res.aetherload.net:1080"
  proxyUsername: string;  // e.g. "customer-apex-zone-us-res"
  proxyPassword: string;
  deviceProfile: {
    userAgent: string;
    viewport: { width: number; height: number };
    deviceScaleFactor: number;
    isMobile: boolean;
    hasTouch: boolean;
    platform: string;
    secChUa: string;
  };
  behavior: {
    scrollDepthPct: number;
    bounceRatePct: number;
    minDwellMs: number;
    maxDwellMs: number;
  };
}

export interface MetricTelemetry {
  workerId: string;
  timestamp: number;
  statusCode: number;
  dnsDurationMs: number;
  tcpDurationMs: number;
  tlsDurationMs: number;
  ttfbMs: number;
  domContentLoadedMs: number;
  cdnCacheHeader: string | null;
  transferredBytes: number;
}

export async function executeSyntheticBrowserSession(
  config: WorkerTaskConfig,
  emitTelemetry: (metric: MetricTelemetry) => Promise<void>
): Promise<void> {
  // 1. Launch Isolated Chromium Instance with anti-detection flags
  const browser = await chromium.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
      '--disable-infobars',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--window-position=0,0',
    ],
  });

  // 2. Build Context with Spoofed Device & Authenticated Proxy
  const context: BrowserContext = await browser.newContext({
    proxy: {
      server: config.proxyUrl,
      username: config.proxyUsername,
      password: config.proxyPassword,
    },
    userAgent: config.deviceProfile.userAgent,
    viewport: config.deviceProfile.viewport,
    deviceScaleFactor: config.deviceProfile.deviceScaleFactor,
    isMobile: config.deviceProfile.isMobile,
    hasTouch: config.deviceProfile.hasTouch,
    extraHTTPHeaders: {
      'Sec-CH-UA': config.deviceProfile.secChUa,
      'Sec-CH-UA-Mobile': config.deviceProfile.isMobile ? '?1' : '?0',
      'Sec-CH-UA-Platform': \`"\${config.deviceProfile.platform}"\`,
      'Accept-Language': 'en-US,en;q=0.9',
      'Upgrade-Insecure-Requests': '1',
    },
  });

  // 3. Inject evasive stealth scripts into DOM before scripts load
  await context.addInitScript(() => {
    // Mask navigator.webdriver
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    // Mask chrome runtime
    (window as any).chrome = { runtime: {} };
    // Mask permissions query
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters: any) =>
      parameters.name === 'notifications'
        ? Promise.resolve({ state: Notification.permission } as any)
        : originalQuery(parameters);
  });

  const page: Page = await context.newPage();

  try {
    const startTime = performance.now();
    let initialResponse: Response | null = null;

    // 4. Navigate to Target URL with high-resolution timing
    initialResponse = await page.goto(config.targetUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 30000,
    });

    const domLoadedTime = performance.now();
    const serverTiming = initialResponse?.request().timing();
    const headers = initialResponse?.headers() || {};

    const metric: MetricTelemetry = {
      workerId: config.workerId,
      timestamp: Date.now(),
      statusCode: initialResponse?.status() || 0,
      dnsDurationMs: Math.max(0, (serverTiming?.domainLookupEnd || 0) - (serverTiming?.domainLookupStart || 0)),
      tcpDurationMs: Math.max(0, (serverTiming?.connectEnd || 0) - (serverTiming?.connectStart || 0)),
      tlsDurationMs: Math.max(0, (serverTiming?.secureConnectionStart || 0) > 0 ? (serverTiming?.connectEnd || 0) - (serverTiming?.secureConnectionStart || 0) : 0),
      ttfbMs: Math.max(0, (serverTiming?.responseStart || 0) - (serverTiming?.requestStart || 0)),
      domContentLoadedMs: Math.round(domLoadedTime - startTime),
      cdnCacheHeader: headers['cf-cache-status'] || headers['x-cache'] || headers['fastly-debug-digest'] || null,
      transferredBytes: (await initialResponse?.body())?.byteLength || 0,
    };

    await emitTelemetry(metric);

    // 5. Simulate Human Behavioral Interaction (Scroll & Dwell)
    if (Math.random() * 100 > config.behavior.bounceRatePct) {
      // Smooth viewport scroll to simulated target depth
      const targetScrollY = Math.round(
        (await page.evaluate(() => document.body.scrollHeight)) * (config.behavior.scrollDepthPct / 100)
      );

      await page.evaluate((targetY) => {
        window.scrollTo({ top: targetY, behavior: 'smooth' });
      }, targetScrollY);

      // Random dwell / think time between min and max
      const dwellMs = Math.floor(
        Math.random() * (config.behavior.maxDwellMs - config.behavior.minDwellMs) + config.behavior.minDwellMs
      );
      await page.waitForTimeout(dwellMs);
    }
  } catch (err: any) {
    console.error(\`Worker \${config.workerId} encountered error:\`, err.message);
  } finally {
    await context.close();
    await browser.close();
  }
}
`;

export const GO_WORKER_ROUTINE_CODE = `// ============================================================================
// AETHERLOAD HIGH-THROUGHPUT GO WORKER (Sub-Millisecond HTTP Flood Routine)
// Optimized for 100,000+ requests/sec per node with SOCKS5 Proxy Dialing,
// Custom TLS Fingerprint Mimicry, and Atomic Metrics Emission.
// ============================================================================

package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"sync/atomic"
	"time"

	"golang.org/x/net/proxy"
)

type WorkerConfig struct {
	TargetURL       string
	ProxySocksAddr  string // e.g. "proxy-res-pool.aetherload.net:1080"
	ProxyUsername   string
	ProxyPassword   string
	UserAgent       string
	SecChUa         string
	Platform        string
	RequestsPerSec  int
	WorkerGoroutines int
}

type MetricsCollector struct {
	TotalRequests uint64
	Success2xx    uint64
	RateLimit429  uint64
	Server5xx     uint64
	TotalTTFBNs   uint64
}

func SpawnGoLoadWorker(ctx context.Context, cfg WorkerConfig, metrics *MetricsCollector) {
	// 1. Configure Authenticated SOCKS5 Dialer for Geo-Routing
	auth := &proxy.Auth{
		User:     cfg.ProxyUsername,
		Password: cfg.ProxyPassword,
	}

	dialer, err := proxy.SOCKS5("tcp", cfg.ProxySocksAddr, auth, proxy.Direct)
	if err != nil {
		fmt.Printf("Failed to initialize SOCKS5 dialer: %v\\n", err)
		return
	}

	// 2. Custom HTTP/2 & Keep-Alive Transport with Connection Pooling
	transport := &http.Transport{
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			return dialer.Dial(network, addr)
		},
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: false,
			MinVersion:         tls.VersionTLS12,
		},
		MaxIdleConns:        1000,
		MaxIdleConnsPerHost: 200,
		IdleConnTimeout:     90 * time.Second,
		DisableCompression:  false,
		ForceAttemptHTTP2:   true,
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   15 * time.Second,
	}

	// 3. Goroutine Worker Fan-Out
	for i := 0; i < cfg.WorkerGoroutines; i++ {
		go func(workerID int) {
			reqInterval := time.Second / time.Duration(cfg.RequestsPerSec/cfg.WorkerGoroutines)
			ticker := time.NewTicker(reqInterval)
			defer ticker.Stop()

			for {
				select {
				case <-ctx.Done():
					return
				case <-ticker.C:
					executeHTTPRequest(client, cfg, metrics)
				}
			}
		}(i)
	}
}

func executeHTTPRequest(client *http.Client, cfg WorkerConfig, metrics *MetricsCollector) {
	req, err := http.NewRequest("GET", cfg.TargetURL, nil)
	if err != nil {
		return
	}

	// Inject Spoofed Browser Headers to match target profile
	req.Header.Set("User-Agent", cfg.UserAgent)
	req.Header.Set("Sec-CH-UA", cfg.SecChUa)
	req.Header.Set("Sec-CH-UA-Mobile", "?0")
	req.Header.Set("Sec-CH-UA-Platform", fmt.Sprintf("\\"%s\\"", cfg.Platform))
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")

	start := time.Now()
	resp, err := client.Do(req)
	duration := time.Since(start)

	atomic.AddUint64(&metrics.TotalRequests, 1)
	atomic.AddUint64(&metrics.TotalTTFBNs, uint64(duration.Nanoseconds()))

	if err != nil {
		atomic.AddUint64(&metrics.Server5xx, 1)
		return
	}
	defer resp.Body.Close()

	switch {
	case resp.StatusCode >= 200 && resp.StatusCode < 400:
		atomic.AddUint64(&metrics.Success2xx, 1)
	case resp.StatusCode == 429:
		atomic.AddUint64(&metrics.RateLimit429, 1)
	case resp.StatusCode >= 500:
		atomic.AddUint64(&metrics.Server5xx, 1)
	}
}
`;

export const OPENAPI_SWAGGER_SPEC = {
  openapi: '3.1.0',
  info: {
    title: 'AetherLoad Synthetic Traffic Engine API',
    version: '1.0.0',
    description:
      'High-throughput synthetic user simulation and geo-targeted load testing platform. Orchestrates headless browser clusters and Go HTTP workers across residential, datacenter, and mobile proxies.',
    contact: {
      name: 'AetherLoad Platform Engineering',
      url: 'https://aetherload.dev/support',
    },
  },
  servers: [
    {
      url: 'https://api.aetherload.dev/v1',
      description: 'Production Global API Gateway',
    },
  ],
  paths: {
    '/scenarios': {
      post: {
        summary: 'Create Traffic Scenario',
        description: 'Creates a reproducible synthetic load scenario with device mix, ramp curve, and proxy geo-targets.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['name', 'targetUrl', 'workerType', 'peakConcurrency', 'durationSeconds'],
                properties: {
                  name: { type: 'string', example: 'Black Friday Checkout Stress' },
                  targetUrl: { type: 'string', format: 'uri', example: 'https://shop.example.com/checkout' },
                  workerType: { type: 'string', enum: ['go_http', 'playwright_browser'], example: 'playwright_browser' },
                  pattern: { type: 'string', enum: ['ramp', 'steady', 'spike', 'step'], example: 'spike' },
                  peakConcurrency: { type: 'integer', minimum: 1, maximum: 50000, example: 5000 },
                  durationSeconds: { type: 'integer', minimum: 10, maximum: 3600, example: 120 },
                  proxyType: { type: 'string', enum: ['datacenter', 'residential', 'mobile'], example: 'residential' },
                  targetRegions: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        regionId: { type: 'string', example: 'us-east' },
                        weightPct: { type: 'integer', example: 50 },
                      },
                    },
                  },
                },
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'Scenario created successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    id: { type: 'string', format: 'uuid' },
                    name: { type: 'string' },
                    estimatedCredits: { type: 'integer' },
                    domainVerified: { type: 'boolean' },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/runs': {
      post: {
        summary: 'Initiate Simulation Run',
        description: 'Dispatches worker pods in Kubernetes clusters via KEDA and BullMQ job queue.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['scenarioId'],
                properties: {
                  scenarioId: { type: 'string', format: 'uuid' },
                  overrideConcurrency: { type: 'integer' },
                  dryRun: { type: 'boolean', default: false },
                },
              },
            },
          },
        },
        responses: {
          '202': {
            description: 'Job queued and worker orchestration underway',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    jobId: { type: 'string', format: 'uuid' },
                    status: { type: 'string', example: 'provisioning' },
                    assignedCluster: { type: 'string', example: 'k8s-us-east-pool-04' },
                    telemetryStreamUrl: { type: 'string', example: '/v1/runs/job_99812/metrics/realtime' },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/runs/{id}/kill': {
      post: {
        summary: 'Emergency Kill-Switch',
        description: 'Instantly aborts all distributed worker nodes and gracefully drains proxy connections within 250ms.',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: {
          '200': {
            description: 'Simulation stopped immediately by operator',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    jobId: { type: 'string' },
                    status: { type: 'string', example: 'killed' },
                    stoppedAt: { type: 'string', format: 'date-time' },
                    activeWorkersRemaining: { type: 'integer', example: 0 },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/workers/health': {
      get: {
        summary: 'Cluster & Proxy Health Status',
        description: 'Returns real-time capacity and latency metrics for all global worker clusters and egress proxy pools.',
        responses: {
          '200': {
            description: 'Healthy cluster state',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    clusterStatus: { type: 'string', example: 'operational' },
                    totalAvailablePods: { type: 'integer', example: 420 },
                    proxyPools: {
                      type: 'array',
                      items: {
                        type: 'object',
                        properties: {
                          poolType: { type: 'string' },
                          activeIps: { type: 'integer' },
                          healthScorePct: { type: 'number' },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  },
};
