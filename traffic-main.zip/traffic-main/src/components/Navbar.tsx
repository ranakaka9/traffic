import React from 'react';
import {
  Activity,
  Network,
  Database,
  Code2,
  Terminal,
  ShieldCheck,
  CreditCard,
  Flame,
  Globe2,
} from 'lucide-react';
import { SaaSUser } from '../types';

export type NavTab =
  | 'simulator'
  | 'architecture'
  | 'database'
  | 'worker-code'
  | 'api-swagger'
  | 'security';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  user: SaaSUser;
  isSimulating: boolean;
  onOpenVerifyModal: () => void;
  onOpenBillingModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  user,
  isSimulating,
  onOpenVerifyModal,
  onOpenBillingModal,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      {/* Top Banner Status Bar */}
      <div className="px-4 py-1.5 bg-slate-900 border-b border-slate-800/80 text-xs flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 text-emerald-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Global Grid: 12 K8s Worker Clusters Operational
          </span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-400 font-mono">
            Egress Proxy Pool: 3,560,000+ Clean Residential & Mobile IPs
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenVerifyModal}
            className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer text-xs font-medium border border-slate-700"
            aria-label="Domain Verification & Safety Gate"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
            Domain Safety Gate
          </button>

          <button
            onClick={onOpenBillingModal}
            className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 hover:text-emerald-100 transition cursor-pointer text-xs font-mono border border-emerald-800"
            aria-label="View Subscription & Credits"
          >
            <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
            <span>{user.creditsRemaining.toLocaleString()} Credits</span>
            <span className="px-1.5 py-0.2 bg-emerald-700 text-[10px] text-white rounded font-bold uppercase">
              {user.tier}
            </span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-sky-600 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-sky-500/20">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-sky-300 bg-clip-text text-transparent">
                  AetherLoad
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800/80 font-mono font-medium">
                  v2.4 LTS
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-none">
                Global Synthetic Traffic & Load Simulation Engine
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => onSelectTab('simulator')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                currentTab === 'simulator'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              Engine & Live Telemetry
              {isSimulating && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping ml-0.5" />
              )}
            </button>

            <button
              onClick={() => onSelectTab('architecture')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                currentTab === 'architecture'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Network className="w-3.5 h-3.5" />
              Architecture & Data Flow
            </button>

            <button
              onClick={() => onSelectTab('database')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                currentTab === 'database'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              Database Schema (DDL)
            </button>

            <button
              onClick={() => onSelectTab('worker-code')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                currentTab === 'worker-code'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              Worker Node Code
            </button>

            <button
              onClick={() => onSelectTab('api-swagger')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                currentTab === 'api-swagger'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              OpenAPI / Swagger
            </button>

            <button
              onClick={() => onSelectTab('security')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                currentTab === 'security'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Security & K8s Roadmap
            </button>
          </nav>

          {/* Quick Active Status Badge */}
          <div className="flex items-center gap-2">
            {isSimulating ? (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-medium animate-pulse">
                <Flame className="w-3.5 h-3.5" />
                <span>Simulation Active</span>
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-400 text-xs">
                <Globe2 className="w-3.5 h-3.5 text-sky-400" />
                <span>Ready for Load Test</span>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Nav Tabs */}
        <div className="flex lg:hidden overflow-x-auto py-2 gap-1 border-t border-slate-800/60 no-scrollbar">
          {[
            { id: 'simulator', label: 'Engine & Telemetry', icon: Flame },
            { id: 'architecture', label: 'Architecture', icon: Network },
            { id: 'database', label: 'Database DDL', icon: Database },
            { id: 'worker-code', label: 'Worker Code', icon: Code2 },
            { id: 'api-swagger', label: 'OpenAPI', icon: Terminal },
            { id: 'security', label: 'Security & K8s', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id as NavTab)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer ${
                  active
                    ? 'bg-sky-600 text-white'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-900'
                }`}
              >
                <Icon className="w-3 h-3" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
