import React, { useState } from 'react';
import { X, CreditCard, Check, Zap, Shield, Crown, Calculator } from 'lucide-react';
import { SaaSPlanTier } from '../types';
import { calculateUsageCredits } from '../lib/simulation-engine';

interface BillingCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTier: SaaSPlanTier;
  creditsRemaining: number;
  onSelectTier: (tier: SaaSPlanTier) => void;
}

export const BillingCalculatorModal: React.FC<BillingCalculatorModalProps> = ({
  isOpen,
  onClose,
  currentTier,
  creditsRemaining,
  onSelectTier,
}) => {
  const [calcDuration, setCalcDuration] = useState<number>(60);
  const [calcConcurrency, setCalcConcurrency] = useState<number>(2000);
  const [calcProxy, setCalcProxy] = useState<'datacenter' | 'residential' | 'mobile'>('residential');
  const [calcEngine, setCalcEngine] = useState<'go_http' | 'playwright_browser'>('playwright_browser');

  const estimate = calculateUsageCredits({
    durationSeconds: calcDuration,
    peakConcurrency: calcConcurrency,
    proxyTier: calcProxy,
    workerType: calcEngine,
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full p-6 shadow-2xl space-y-6 text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">SaaS Tiers & Metered Usage Architecture</h2>
              <p className="text-xs text-slate-400">
                Stripe/Paddle real-time credit deduction based on compute units and proxy network egress.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tier Cards Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Free Tier */}
          <div
            className={`p-5 rounded-2xl border transition flex flex-col justify-between ${
              currentTier === 'free'
                ? 'bg-slate-950 border-sky-400 ring-1 ring-sky-400'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-400 uppercase">Starter</span>
                {currentTier === 'free' && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800">
                    CURRENT
                  </span>
                )}
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Free Community</h3>
                <p className="text-xs text-slate-400 mt-1">$0 / month</p>
              </div>

              <ul className="text-xs text-slate-300 space-y-2 pt-2 border-t border-slate-800">
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Max 50 Concurrent VUs</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Datacenter IPs Only</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Basic Desktop Browser Profiles</span>
                </li>
                <li className="flex items-center gap-1.5 text-slate-500">
                  <X className="w-3.5 h-3.5" />
                  <span>No Residential/Mobile IPs</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => onSelectTier('free')}
              className="mt-6 w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition cursor-pointer"
            >
              Select Free
            </button>
          </div>

          {/* Pro Tier */}
          <div
            className={`p-5 rounded-2xl border transition flex flex-col justify-between relative ${
              currentTier === 'pro'
                ? 'bg-sky-950/40 border-sky-400 ring-2 ring-sky-400'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-sky-400 uppercase flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5" />
                  PRO TIER
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800">
                  POPULAR
                </span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">$249 / month</h3>
                <p className="text-xs text-slate-400 mt-1">Includes 500,000 Compute Credits</p>
              </div>

              <ul className="text-xs text-slate-300 space-y-2 pt-2 border-t border-slate-800">
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Up to 10,000 Concurrent VUs</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Residential & Datacenter Pools</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Full Mobile (iOS/Android) Spoofing</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>REST API & Webhook Access</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => onSelectTier('pro')}
              className="mt-6 w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-xs font-semibold text-white transition cursor-pointer shadow-md"
            >
              {currentTier === 'pro' ? 'Current Active Tier' : 'Upgrade to Pro'}
            </button>
          </div>

          {/* Enterprise Tier */}
          <div
            className={`p-5 rounded-2xl border transition flex flex-col justify-between ${
              currentTier === 'enterprise'
                ? 'bg-purple-950/40 border-purple-400 ring-2 ring-purple-400'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-purple-400 uppercase flex items-center gap-1">
                  <Crown className="w-3.5 h-3.5" />
                  ENTERPRISE
                </span>
                {currentTier === 'enterprise' && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
                    ACTIVE
                  </span>
                )}
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Custom / Scale</h3>
                <p className="text-xs text-slate-400 mt-1">Volume billing via Stripe Metronome</p>
              </div>

              <ul className="text-xs text-slate-300 space-y-2 pt-2 border-t border-slate-800">
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>100,000+ Concurrent VUs</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Dedicated Mobile 5G Proxy Clusters</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Private VPC K8s Worker Deployments</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Custom Anti-Bot Bypasses & SLAs</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => onSelectTier('enterprise')}
              className="mt-6 w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white transition cursor-pointer shadow-md"
            >
              Contact Enterprise Sales
            </button>
          </div>
        </div>

        {/* Real-Time Metering Calculator */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono uppercase text-slate-300 font-bold flex items-center gap-2">
              <Calculator className="w-4 h-4 text-sky-400" />
              Interactive Credit Deduction Calculator
            </h3>
            <span className="text-xs font-mono text-emerald-400 font-semibold">
              Remaining: {creditsRemaining.toLocaleString()} Credits
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
            <div className="space-y-1">
              <label className="text-slate-400">Duration (seconds)</label>
              <input
                type="number"
                min="10"
                max="3600"
                value={calcDuration}
                onChange={(e) => setCalcDuration(Math.max(1, parseInt(e.target.value, 10) || 10))}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 font-mono text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">Concurrency (VUs)</label>
              <input
                type="number"
                min="50"
                max="50000"
                value={calcConcurrency}
                onChange={(e) =>
                  setCalcConcurrency(Math.max(1, parseInt(e.target.value, 10) || 100))
                }
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 font-mono text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">Proxy Egress Tier</label>
              <select
                value={calcProxy}
                onChange={(e) => setCalcProxy(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 font-mono text-white focus:outline-none focus:border-sky-500 cursor-pointer"
              >
                <option value="datacenter">Datacenter (1x weight)</option>
                <option value="residential">Residential (3x weight)</option>
                <option value="mobile">Mobile 5G (6x weight)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">Worker Node Engine</label>
              <select
                value={calcEngine}
                onChange={(e) => setCalcEngine(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 font-mono text-white focus:outline-none focus:border-sky-500 cursor-pointer"
              >
                <option value="playwright_browser">Playwright DOM (4x compute)</option>
                <option value="go_http">Go HTTP Flood (1x compute)</option>
              </select>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Calculated Metered Deductions:</span>
            <div className="flex items-center gap-3">
              <span className="text-sky-300 font-bold">
                {estimate.creditsDeducted.toLocaleString()} Credits
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-emerald-400 font-bold">
                ${estimate.estimatedCostUsd.toFixed(2)} USD
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
