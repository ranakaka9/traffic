import React from 'react';
import {
  Flame,
  Activity,
  AlertOctagon,
  Clock,
  Gauge,
  Globe,
  Radio,
  CheckCircle2,
  Terminal,
  Server,
  Zap,
} from 'lucide-react';
import { SimulationTelemetry, ScenarioConfig } from '../types';

interface LiveTelemetryDashboardProps {
  telemetry: SimulationTelemetry;
  scenario: ScenarioConfig;
  onKillSwitch: () => void;
  onReset: () => void;
}

export const LiveTelemetryDashboard: React.FC<LiveTelemetryDashboardProps> = ({
  telemetry,
  scenario,
  onKillSwitch,
  onReset,
}) => {
  const isFinished = telemetry.elapsedSeconds >= scenario.durationSeconds || telemetry.isKilled;
  const progressPct = Math.min(
    100,
    Math.round((telemetry.elapsedSeconds / scenario.durationSeconds) * 100)
  );

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6 text-slate-100">
      {/* Top Banner: Status, Timer & Kill-Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              telemetry.isKilled
                ? 'bg-red-950 border border-red-800 text-red-400'
                : isFinished
                ? 'bg-emerald-950 border border-emerald-800 text-emerald-400'
                : 'bg-amber-950 border border-amber-800 text-amber-400 animate-pulse'
            }`}
          >
            {telemetry.isKilled ? (
              <AlertOctagon className="w-5 h-5" />
            ) : isFinished ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <Flame className="w-5 h-5" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base text-white">
                {telemetry.isKilled
                  ? 'Simulation Aborted via Emergency Kill-Switch'
                  : isFinished
                  ? 'Synthetic Load Run Completed'
                  : 'Synthetic Traffic Flood Active'}
              </span>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                  telemetry.isKilled
                    ? 'bg-red-900/60 text-red-300 border border-red-700'
                    : isFinished
                    ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                    : 'bg-amber-900/60 text-amber-300 border border-amber-700 animate-pulse'
                }`}
              >
                {telemetry.isKilled ? 'KILLED' : isFinished ? 'COMPLETED' : 'RUNNING'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 font-mono">
              Target: {scenario.targetUrl} • {scenario.workerType === 'playwright_browser' ? 'Playwright Headless' : 'Go HTTP Flood'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {!isFinished ? (
            <button
              onClick={onKillSwitch}
              className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-lg shadow-red-600/30 flex items-center gap-2 border border-red-400"
              aria-label="Emergency Kill-Switch: Terminate All Workers"
            >
              <AlertOctagon className="w-4 h-4" />
              Emergency Kill-Switch
            </button>
          ) : (
            <button
              onClick={onReset}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition cursor-pointer border border-slate-700"
            >
              Configure New Run
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar & Timing */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            Elapsed: {telemetry.elapsedSeconds}s / {scenario.durationSeconds}s
          </span>
          <span className="text-sky-300 font-bold">{progressPct}% Complete</span>
        </div>
        <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
          <div
            className={`h-full transition-all duration-300 ${
              telemetry.isKilled
                ? 'bg-red-500'
                : isFinished
                ? 'bg-emerald-500'
                : 'bg-gradient-to-r from-sky-500 via-indigo-500 to-amber-400'
            }`}
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Primary Telemetry Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {/* Active VUs */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            Active Concurrency
          </span>
          <div className="text-xl font-bold font-mono text-white flex items-center gap-1">
            <Gauge className="w-4 h-4 text-sky-400" />
            {telemetry.activeVUs.toLocaleString()}
            <span className="text-xs text-slate-500 font-normal">VUs</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono block">Peak: {scenario.peakConcurrency.toLocaleString()}</span>
        </div>

        {/* Current RPS */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            Throughput (RPS)
          </span>
          <div className="text-xl font-bold font-mono text-emerald-400 flex items-center gap-1">
            <Activity className="w-4 h-4 text-emerald-400" />
            {telemetry.currentRps.toLocaleString()}
            <span className="text-xs text-slate-500 font-normal">req/s</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono block">HTTP/2 Multiplexed</span>
        </div>

        {/* P95 TTFB */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            P95 Tail Latency
          </span>
          <div className="text-xl font-bold font-mono text-sky-300">
            {telemetry.latency.p95.toFixed(1)}
            <span className="text-xs text-slate-500 font-normal">ms</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono block">
            p50: {telemetry.latency.p50.toFixed(0)}ms • p99: {telemetry.latency.p99.toFixed(0)}ms
          </span>
        </div>

        {/* Total Dispatched Requests */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            Total Dispatched
          </span>
          <div className="text-xl font-bold font-mono text-indigo-300">
            {telemetry.totalRequests.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500 font-mono block">Egress packets</span>
        </div>

        {/* CDN Cache Hit Ratio */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            CDN Cache Hit %
          </span>
          <div className="text-xl font-bold font-mono text-amber-300">
            {(telemetry.cdnCache.hitRatio * 100).toFixed(1)}%
          </div>
          <span className="text-[10px] text-slate-500 font-mono block">Edge cache ratio</span>
        </div>

        {/* Bandwidth Mbps */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
            Egress Bandwidth
          </span>
          <div className="text-xl font-bold font-mono text-cyan-300">
            {telemetry.bandwidthMbps.toFixed(1)}
            <span className="text-xs text-slate-500 font-normal">Mbps</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono block">Proxy data rate</span>
        </div>
      </div>

      {/* HTTP Status Code Pill Counters */}
      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
          HTTP Response Status Code Breakdown:
        </span>
        <div className="flex flex-wrap items-center gap-2">
          <div className="px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300">
            <span className="font-bold">200 OK:</span> {telemetry.statusCodes['200'].toLocaleString()}
          </div>
          <div className="px-2.5 py-1 rounded-lg bg-sky-950/60 border border-sky-800 text-sky-300">
            <span className="font-bold">304 Not Modified:</span> {telemetry.statusCodes['304'].toLocaleString()}
          </div>
          <div className="px-2.5 py-1 rounded-lg bg-amber-950/60 border border-amber-800 text-amber-300">
            <span className="font-bold">429 Rate Limited:</span> {telemetry.statusCodes['429'].toLocaleString()}
          </div>
          <div className="px-2.5 py-1 rounded-lg bg-red-950/60 border border-red-800 text-red-300">
            <span className="font-bold">5xx Server Errors:</span>{' '}
            {(telemetry.statusCodes['500'] + telemetry.statusCodes['503']).toLocaleString()}
          </div>
        </div>
      </div>

      {/* Live Distributed Worker Terminal Stream */}
      <div className="p-4 rounded-xl bg-black border border-slate-800 space-y-2">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
            <Terminal className="w-3.5 h-3.5" />
            <span>Distributed Worker Pod Telemetry Stream (SSE Ingest)</span>
          </div>
          <span className="text-[10px] font-mono text-slate-500">
            Kafka Topic: telemetry.events.v1
          </span>
        </div>

        <div className="font-mono text-[11px] text-slate-300 space-y-1 max-h-48 overflow-y-auto no-scrollbar">
          {telemetry.logs.length === 0 ? (
            <div className="text-slate-600 italic py-2">Awaiting first telemetry batch from K8s worker pods...</div>
          ) : (
            telemetry.logs.map((log) => (
              <div key={log.id} className="flex items-center gap-2 leading-relaxed">
                <span className="text-slate-500">{log.timestamp}</span>
                <span className="text-sky-400">[{log.region}]</span>
                <span className="text-slate-400">{log.workerId}</span>
                <span className="text-indigo-300 font-semibold">{log.device}</span>
                <span className="text-slate-400 font-mono">({log.ip})</span>
                <span className="text-emerald-400 font-bold">{log.status}</span>
                <span className="text-sky-300">{log.ttfbMs}ms</span>
                <span
                  className={`text-[10px] px-1 rounded ${
                    log.cacheStatus === 'HIT'
                      ? 'bg-emerald-950 text-emerald-400'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {log.cacheStatus}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
