import React, { useState } from 'react';
import {
  Server,
  Network,
  Cpu,
  Layers,
  ShieldAlert,
  ArrowRight,
  Database,
  Radio,
  Zap,
  Globe,
  CheckCircle2,
  Lock,
  RefreshCw,
} from 'lucide-react';

interface FlowStep {
  step: number;
  title: string;
  source: string;
  destination: string;
  protocol: string;
  latencySla: string;
  description: string;
  payloadSummary: string;
  failureRecovery: string;
}

const FLOW_STEPS: FlowStep[] = [
  {
    step: 1,
    title: 'Scenario Trigger & Authentication',
    source: 'Frontend Dashboard (React/Tailwind)',
    destination: 'API Gateway (NestJS / Go Fiber)',
    protocol: 'HTTPS (TLS 1.3) / JWT Bearer',
    latencySla: '< 45ms',
    description:
      'Operator or CI/CD pipeline triggers synthetic load scenario. The gateway validates API key, verifies domain ownership status, checks available compute credits, and enforces tenancy rate limits.',
    payloadSummary: '{ scenarioId, peakVUs: 5000, durationSec: 120, proxyTier: "residential" }',
    failureRecovery: '403 Forbidden if domain unverified; 402 Payment Required if credits insufficient.',
  },
  {
    step: 2,
    title: 'Job Scheduling & Queue Partitioning',
    source: 'API Orchestrator',
    destination: 'Distributed Queue (Redis BullMQ + Kafka)',
    protocol: 'TCP / Redis Protocol (RESP3) / Kafka Wire',
    latencySla: '< 10ms',
    description:
      'The API Orchestrator decomposes the 5,000 VU load into regional sub-tasks (e.g. 2,000 US-East, 1,500 EU-Central, 1,500 AP-Tokyo) and publishes jobs to regional BullMQ priority queues.',
    payloadSummary: 'Partitioned Job chunks with concurrency ramp curves and assigned proxy credentials.',
    failureRecovery: 'Redis AOF persistence + dead-letter queue (DLQ) with 3x retry backoff.',
  },
  {
    step: 3,
    title: 'K8s Cluster Auto-Scaling via KEDA',
    source: 'BullMQ Queue Depth Metric',
    destination: 'K8s Pod Autoscaler (KEDA)',
    protocol: 'Kubernetes Custom Metrics API',
    latencySla: '< 2.5s (Scale to Target)',
    description:
      'KEDA (Kubernetes Event-driven Autoscaling) monitors BullMQ queue lag. It automatically scales worker deployments (Playwright Chromium pods or Go worker pods) from 0 to target replica count across regional worker clusters.',
    payloadSummary: 'ScaledObject triggers HPA to spawn 25 worker pods (200 VUs each).',
    failureRecovery: 'Pre-warmed warm-pool pods absorb burst; spot node termination triggers instant re-schedule.',
  },
  {
    step: 4,
    title: 'Worker Egress & SOCKS5 Proxy Rotation',
    source: 'Worker Nodes (Playwright / Go)',
    destination: 'Proxy Gateway Layer (Egress Rotator)',
    protocol: 'SOCKS5 with Username/Password Auth',
    latencySla: '< 30ms proxy overhead',
    description:
      'Worker instances dial out through localized SOCKS5 proxy pools. The proxy layer rotates residential, mobile 5G, or datacenter exit IPs, masking origin worker cloud IPs and providing country/city geo-presence.',
    payloadSummary: 'SOCKS5 CONNECT with session-stickiness token and geo-tag headers.',
    failureRecovery: 'Unresponsive proxy IPs automatically dropped from active pool via continuous health probes.',
  },
  {
    step: 5,
    title: 'Synthetic Traffic Delivery to Target',
    source: 'Proxy Egress Pool',
    destination: 'Target Site & CDN Edge (User Infrastructure)',
    protocol: 'HTTP/1.1, HTTP/2, HTTP/3 (QUIC) over TLS 1.3',
    latencySla: 'Real-world network RTT (20ms - 250ms)',
    description:
      'Synthetic requests hit target CDN edge (Cloudflare, Fastly, CloudFront) or origin server. Requests carry authentic device Client Hints (Sec-CH-UA, Viewport, Platform) and execute behavioral scroll/click events.',
    payloadSummary: 'GET /checkout/cart with authentic browser headers, cookies, and human scroll actions.',
    failureRecovery: 'If target returns > 15% HTTP 5xx or 429, emergency kill-switch or back-off curve engages.',
  },
  {
    step: 6,
    title: 'High-Throughput Telemetry Ingestion',
    source: 'Worker Node Telemetry Producers',
    destination: 'ClickHouse / TimescaleDB Ingestion Cluster',
    protocol: 'gRPC streaming / Apache Kafka Topic',
    latencySla: '< 100ms pipeline lag',
    description:
      'Workers continuously emit millisecond-resolution metrics (DNS time, TCP connect, TLS handshake, TTFB, DOMContentLoaded, LCP, status code, CDN cache header) via high-throughput Kafka topics into ClickHouse.',
    payloadSummary: 'Batch of 5,000 metric rows per second compressed with zstd.',
    failureRecovery: 'Local worker in-memory ring-buffer prevents data loss during transient network partitions.',
  },
  {
    step: 7,
    title: 'Live Dashboard Broadcast & Aggregation',
    source: 'Metrics Aggregator Service',
    destination: 'Operator Dashboard (SSE / WebSocket)',
    protocol: 'Server-Sent Events (SSE) / WSS',
    latencySla: '< 250ms UI update cycle',
    description:
      'Aggregator computes 1-second rolling percentiles (p50, p95, p99 TTFB, active VUs, cache hit ratio, error distribution) and streams real-time updates directly to the web console.',
    payloadSummary: '{ activeVUs: 5000, currentRps: 12450, p95TtfbMs: 84.2, cdnHitRate: 0.89 }',
    failureRecovery: 'Automatic client reconnection with sequence number replay.',
  },
];

export const ArchitectureViewer: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const selectedStep = FLOW_STEPS.find((s) => s.step === activeStep) || FLOW_STEPS[0];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-sky-950 p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono uppercase tracking-wider mb-2">
              <Network className="w-3.5 h-3.5" />
              Distributed Cloud Architecture
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              System Architecture & End-to-End Data Flow
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Multi-region orchestration blueprint connecting web management, distributed job queues,
              elastic K8s worker clusters, proxy rotation gateways, and sub-second metrics ingestion.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
            <div className="px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span>Orchestrator: KEDA + K8s</span>
            </div>
            <div className="px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-400" />
              <span>Queue: BullMQ / Kafka</span>
            </div>
            <div className="px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span>Storage: ClickHouse</span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Visual Diagram (SVG / Flow Canvas) */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            Interactive Data Flow Diagram (Click a node or step below)
          </h2>
          <span className="text-xs text-slate-400 font-mono">Step {activeStep} of 7</span>
        </div>

        {/* Visual Architecture Map */}
        <div className="grid grid-cols-1 md:grid-cols-7 gap-3 py-4 overflow-x-auto min-w-[760px]">
          {/* Node 1: Web UI */}
          <button
            onClick={() => setActiveStep(1)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 1
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 1</span>
              <h3 className="font-semibold text-sm text-white mt-1">Web Console</h3>
              <p className="text-[11px] text-slate-400 mt-1">React, Next.js, SSE & Tailwind UI</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Port 443</span>
              <Radio className={`w-3.5 h-3.5 ${activeStep === 1 ? 'text-sky-400 animate-pulse' : ''}`} />
            </div>
          </button>

          {/* Node 2: API Gateway */}
          <button
            onClick={() => setActiveStep(2)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 2
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 2</span>
              <h3 className="font-semibold text-sm text-white mt-1">API Gateway</h3>
              <p className="text-[11px] text-slate-400 mt-1">NestJS / Go Fiber, Auth, Tenancy</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Envoy Proxy</span>
              <Lock className={`w-3.5 h-3.5 ${activeStep === 2 ? 'text-sky-400' : ''}`} />
            </div>
          </button>

          {/* Node 3: Queue Broker */}
          <button
            onClick={() => setActiveStep(3)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 3
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 3</span>
              <h3 className="font-semibold text-sm text-white mt-1">Job Queue</h3>
              <p className="text-[11px] text-slate-400 mt-1">BullMQ (Redis) & Kafka Topics</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Cluster Redis</span>
              <Cpu className={`w-3.5 h-3.5 ${activeStep === 3 ? 'text-sky-400' : ''}`} />
            </div>
          </button>

          {/* Node 4: K8s Worker Nodes */}
          <button
            onClick={() => setActiveStep(4)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 4
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 4</span>
              <h3 className="font-semibold text-sm text-white mt-1">K8s Workers</h3>
              <p className="text-[11px] text-slate-400 mt-1">Playwright & Go Pods + KEDA</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>gVisor Sandbox</span>
              <Zap className={`w-3.5 h-3.5 ${activeStep === 4 ? 'text-sky-400' : ''}`} />
            </div>
          </button>

          {/* Node 5: Proxy Rotator */}
          <button
            onClick={() => setActiveStep(5)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 5
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 5</span>
              <h3 className="font-semibold text-sm text-white mt-1">Proxy Gateway</h3>
              <p className="text-[11px] text-slate-400 mt-1">SOCKS5 Res, Mobile, Datacenter</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Geo Egress</span>
              <Globe className={`w-3.5 h-3.5 ${activeStep === 5 ? 'text-sky-400' : ''}`} />
            </div>
          </button>

          {/* Node 6: Target Infrastructure */}
          <button
            onClick={() => setActiveStep(6)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 6
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 6</span>
              <h3 className="font-semibold text-sm text-white mt-1">Target Origin</h3>
              <p className="text-[11px] text-slate-400 mt-1">User App, CDN Edge, Load Balancer</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Verified Domain</span>
              <Server className={`w-3.5 h-3.5 ${activeStep === 6 ? 'text-sky-400' : ''}`} />
            </div>
          </button>

          {/* Node 7: Metrics Ingestion */}
          <button
            onClick={() => setActiveStep(7)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
              activeStep === 7
                ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">Node 7</span>
              <h3 className="font-semibold text-sm text-white mt-1">ClickHouse / DB</h3>
              <p className="text-[11px] text-slate-400 mt-1">TimescaleDB, Rollup Aggregations</p>
            </div>
            <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>100k rows/s</span>
              <Database className={`w-3.5 h-3.5 ${activeStep === 7 ? 'text-sky-400' : ''}`} />
            </div>
          </button>
        </div>

        {/* Step Navigation Pill Stepper */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800 pt-4">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            {FLOW_STEPS.map((s) => (
              <button
                key={s.step}
                onClick={() => setActiveStep(s.step)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition cursor-pointer flex items-center gap-1.5 ${
                  activeStep === s.step
                    ? 'bg-sky-600 text-white shadow-md'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span>Step {s.step}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveStep((prev) => (prev > 1 ? prev - 1 : 7))}
              className="px-3 py-1 text-xs rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
            >
              Previous
            </button>
            <button
              onClick={() => setActiveStep((prev) => (prev < 7 ? prev + 1 : 1))}
              className="px-3 py-1 text-xs rounded bg-sky-600 hover:bg-sky-500 text-white cursor-pointer font-medium"
            >
              Next Step
            </button>
          </div>
        </div>
      </div>

      {/* Selected Step Drill-Down Card */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800 text-xs font-mono font-bold">
                Step {selectedStep.step} of 7
              </span>
              <h3 className="text-xl font-bold text-white">{selectedStep.title}</h3>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-2">
              <span className="font-medium text-slate-300">{selectedStep.source}</span>
              <ArrowRight className="w-3.5 h-3.5 text-sky-400" />
              <span className="font-medium text-slate-300">{selectedStep.destination}</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
              <span className="text-slate-500 block text-[10px]">PROTOCOL</span>
              <span className="text-sky-300 font-semibold">{selectedStep.protocol}</span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
              <span className="text-slate-500 block text-[10px]">LATENCY SLA</span>
              <span className="text-emerald-400 font-semibold">{selectedStep.latencySla}</span>
            </div>
          </div>
        </div>

        {/* Detailed Explanation */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div>
              <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-1.5">
                Architectural Responsibility & Function
              </h4>
              <p className="text-sm text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800/80">
                {selectedStep.description}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-1.5">
                Fault Tolerance & High Availability Handling
              </h4>
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-950/20 border border-amber-800/30 text-amber-200 text-xs">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p>{selectedStep.failureRecovery}</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider mb-1.5">
                Data Payload Contract
              </h4>
              <pre className="text-xs font-mono bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-slate-300 overflow-x-auto leading-relaxed">
                {selectedStep.payloadSummary}
              </pre>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h4 className="text-xs font-semibold text-white flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Production SLA Enforcements
              </h4>
              <ul className="text-xs text-slate-400 space-y-1.5 list-disc list-inside">
                <li>Automatic circuit breaker on 5xx spike &gt; 15%</li>
                <li>Isolated sandbox namespace per customer run</li>
                <li>Zero data retention on non-aggregated packet dumps</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
