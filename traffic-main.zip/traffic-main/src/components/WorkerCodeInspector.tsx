import React, { useState } from 'react';
import { Code2, Copy, Check, Play, Terminal, CheckCircle2, ShieldAlert } from 'lucide-react';
import { PLAYWRIGHT_WORKER_CODE, GO_WORKER_ROUTINE_CODE, DEVICE_PROFILES } from '../data/mockData';

export const WorkerCodeInspector: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'playwright' | 'go'>('playwright');
  const [copied, setCopied] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);
  const [selectedDevice, setSelectedDevice] = useState<string>('ios18-safari');

  const currentCode = activeTab === 'playwright' ? PLAYWRIGHT_WORKER_CODE : GO_WORKER_ROUTINE_CODE;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunSampleWorker = () => {
    setIsSimulating(true);
    setSimulationLogs([]);

    const profile = DEVICE_PROFILES.find((d) => d.id === selectedDevice) || DEVICE_PROFILES[0];

    const logs: string[] = [
      `[00:00.000] [K8s Pod worker-us-east-89a] Initializing ${activeTab === 'playwright' ? 'Playwright Headless Engine' : 'Go High-RPS Net/HTTP Routine'}`,
      `[00:00.045] [Proxy] Connecting to SOCKS5 tunnel: socks5://res-pool.aetherload.net:1080 (Auth: customer-apex-res)`,
      `[00:00.120] [Egress IP] Assigned Residential Exit IP: 198.51.100.84 (City: Ashburn, VA, US)`,
      `[00:00.180] [Fingerprint] Spoofing Profile: "${profile.name}" (Viewport: ${profile.viewport.width}x${profile.viewport.height}, DPR: ${profile.viewport.dpr})`,
      `[00:00.210] [Headers] Injected Sec-CH-UA: "${profile.clientHints.brands.map((b) => b.brand).join(', ')}" | Platform: "${profile.clientHints.platform}"`,
      `[00:00.350] [HTTP Request] GET https://demo-shop.aetherload.dev/checkout/cart (HTTP/2 Multiplexed)`,
      `[00:00.412] [Timing] DNS: 8ms | TCP: 18ms | TLS: 24ms | TTFB: 32ms (Total Network: 82ms)`,
      `[00:00.460] [Response] HTTP 200 OK | CF-Cache-Status: HIT | Size: 48,290 bytes`,
      activeTab === 'playwright'
        ? `[00:00.720] [DOM Interaction] DOMContentLoaded: 110ms | Executing human scroll to 65% scrollHeight`
        : `[00:00.465] [Atomic Metric] Incremented TotalRequests: +1, Success2xx: +1, Dispatched Next Tick`,
      activeTab === 'playwright'
        ? `[00:01.200] [Dwell Time] Simulating human reading pause for 1,480ms...`
        : `[00:00.470] [Worker Status] Ready for subsequent pipeline dispatch in 2.5ms interval`,
      `[00:01.350] [Telemetry Emit] Emitted metric packet to Kafka topic "worker.telemetry.raw"`,
    ];

    logs.forEach((log, index) => {
      setTimeout(() => {
        setSimulationLogs((prev) => [...prev, log]);
        if (index === logs.length - 1) {
          setIsSimulating(false);
        }
      }, index * 220);
    });
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-sky-950 p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono uppercase tracking-wider mb-2">
              <Code2 className="w-3.5 h-3.5" />
              Core Worker Implementation
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Worker Node Implementation & Interaction Engine
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Production-ready sample code for both full DOM Playwright headless clusters (rich user interaction &
              Core Web Vitals) and ultra-high-throughput Go HTTP flood workers (&gt;100k requests/sec).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition cursor-pointer flex items-center gap-1.5 border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied Code' : 'Copy Source Code'}
            </button>
          </div>
        </div>
      </div>

      {/* Tabs & Code Viewer */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('playwright')}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition cursor-pointer flex items-center gap-2 ${
                activeTab === 'playwright'
                  ? 'bg-sky-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code2 className="w-4 h-4" />
              TypeScript & Playwright Worker (worker.ts)
            </button>
            <button
              onClick={() => setActiveTab('go')}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition cursor-pointer flex items-center gap-2 ${
                activeTab === 'go'
                  ? 'bg-sky-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Terminal className="w-4 h-4 text-emerald-400" />
              Go High-Throughput HTTP Flood (worker.go)
            </button>
          </div>

          {/* Quick Profile Selector for Simulation */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium">Test Device Emulation:</span>
            <select
              value={selectedDevice}
              onChange={(e) => setSelectedDevice(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 px-2.5 py-1.5 rounded-lg font-mono focus:outline-none focus:border-sky-500 cursor-pointer"
            >
              {DEVICE_PROFILES.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <button
              onClick={handleRunSampleWorker}
              disabled={isSimulating}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition cursor-pointer flex items-center gap-1.5 shadow-sm disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              {isSimulating ? 'Executing Worker...' : 'Simulate Single Run'}
            </button>
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <div className="font-semibold text-sky-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Device & Fingerprint Spoofing
            </div>
            <p className="text-slate-400">
              Sec-CH-UA, platform indicators, touch events, viewport scaling, and webdriver stealth masks.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Authenticated SOCKS5 Proxy
            </div>
            <p className="text-slate-400">
              Country and city level routing via residential and mobile proxy pools with sticky session hashing.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <div className="font-semibold text-indigo-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Behavioral Emulation & Metrics
            </div>
            <p className="text-slate-400">
              Realistic scroll depth, natural dwell times, and microsecond-level DNS, TCP, TLS, and TTFB telemetry.
            </p>
          </div>
        </div>

        {/* Code Block */}
        <div className="relative">
          <div className="absolute top-3 right-3 text-[11px] font-mono text-slate-500 uppercase px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
            {activeTab === 'playwright' ? 'TypeScript 5.6 • Playwright 1.48' : 'Go 1.23 • Net/HTTP & SOCKS5'}
          </div>
          <pre className="bg-slate-950 p-5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed max-h-[500px] overflow-y-auto">
            {currentCode}
          </pre>
        </div>

        {/* Live Worker Simulation Console */}
        {simulationLogs.length > 0 && (
          <div className="p-4 rounded-xl bg-black border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-emerald-400 flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5" />
                Live Single Worker Execution Output ({selectedDevice})
              </span>
              {isSimulating && (
                <span className="text-[10px] text-amber-400 font-mono animate-pulse">Running Pod...</span>
              )}
            </div>
            <div className="font-mono text-xs text-slate-300 space-y-1 max-h-48 overflow-y-auto">
              {simulationLogs.map((log, i) => (
                <div key={i} className="leading-snug">
                  {log}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
