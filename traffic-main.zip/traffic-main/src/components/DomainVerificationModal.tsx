import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  Globe,
  FileCode,
  Search,
} from 'lucide-react';
import { verifyDomainRecord, parseRobotsTxt } from '../lib/simulation-engine';

interface DomainVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  domain: string;
  isVerified: boolean;
  onVerifySuccess: () => void;
}

export const DomainVerificationModal: React.FC<DomainVerificationModalProps> = ({
  isOpen,
  onClose,
  domain: initialDomain,
  isVerified,
  onVerifySuccess,
}) => {
  const [domainInput, setDomainInput] = useState<string>(
    initialDomain ? new URL(initialDomain).hostname : 'demo-shop.aetherload.dev'
  );
  const [verificationMethod, setVerificationMethod] = useState<'dns_txt' | 'html_meta'>('dns_txt');
  const [isChecking, setIsChecking] = useState<boolean>(false);
  const [verificationResult, setVerificationResult] = useState<{
    verified: boolean;
    message: string;
  } | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Generated deterministic verification token for this domain
  const token = `token_${domainInput.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 12)}_99`;
  const dnsTxtRecord = `aetherload-verification=${token}`;
  const htmlMetaTag = `<meta name="aetherload-site-verification" content="${token}" />`;

  const sampleRobotsTxt = `User-agent: *
Disallow: /admin/
Disallow: /checkout/payment-token
Crawl-delay: 1.0

User-agent: AetherLoadBot
Disallow: /admin/
Crawl-delay: 0.5`;

  const parsedRobots = parseRobotsTxt(sampleRobotsTxt, 'AetherLoadBot');

  if (!isOpen) return null;

  const handleRunVerification = () => {
    setIsChecking(true);
    setVerificationResult(null);

    setTimeout(() => {
      // Simulate DNS TXT query
      const mockPublishedRecords = [
        'v=spf1 include:_spf.google.com ~all',
        dnsTxtRecord,
      ];

      const res = verifyDomainRecord(domainInput, token, mockPublishedRecords);
      setVerificationResult(res);
      setIsChecking(false);

      if (res.verified) {
        onVerifySuccess();
      }
    }, 700);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-6 text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-950 border border-sky-800 flex items-center justify-center text-sky-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Domain Safety Gate & Compliance Verification</h2>
              <p className="text-xs text-slate-400">
                Prevent unauthorized DDoS testing by proving ownership of the target domain.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Domain Input */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Target FQDN / Domain Name</label>
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Globe className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="text"
                value={domainInput}
                onChange={(e) => setDomainInput(e.target.value)}
                placeholder="example.com"
                className="w-full bg-slate-950 border border-slate-800 focus:border-sky-500 rounded-xl pl-9 pr-4 py-2.5 text-xs font-mono text-white focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Verification Method Switcher */}
        <div className="space-y-3">
          <label className="text-xs font-semibold text-slate-300">Select Ownership Verification Method</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setVerificationMethod('dns_txt')}
              className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                verificationMethod === 'dns_txt'
                  ? 'bg-sky-950/80 border-sky-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="font-semibold text-xs flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-sky-400" />
                DNS TXT Record (Recommended)
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Publish a TXT string on domain root</p>
            </button>

            <button
              onClick={() => setVerificationMethod('html_meta')}
              className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                verificationMethod === 'html_meta'
                  ? 'bg-sky-950/80 border-sky-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="font-semibold text-xs flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                HTML &lt;meta&gt; Tag
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Add meta tag inside &lt;head&gt; element</p>
            </button>
          </div>
        </div>

        {/* Instructions & Record Display */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono text-slate-400">
              {verificationMethod === 'dns_txt' ? 'DNS TXT Record Value:' : 'HTML Tag to Insert:'}
            </span>
            <button
              onClick={() => handleCopy(verificationMethod === 'dns_txt' ? dnsTxtRecord : htmlMetaTag)}
              className="text-sky-400 hover:text-sky-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy Record'}
            </button>
          </div>

          <pre className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs font-mono text-sky-300 break-all">
            {verificationMethod === 'dns_txt' ? dnsTxtRecord : htmlMetaTag}
          </pre>

          <p className="text-[11px] text-slate-400">
            {verificationMethod === 'dns_txt'
              ? 'Add this TXT record to your DNS provider (Cloudflare, Route53, GoDaddy). TTL: 300s.'
              : 'Deploy this meta tag into your production homepage and ensure it is rendered on initial GET.'}
          </p>
        </div>

        {/* Verification Status Feedback */}
        {verificationResult && (
          <div
            className={`p-3.5 rounded-xl border text-xs flex items-center gap-2.5 ${
              verificationResult.verified
                ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                : 'bg-red-950/40 border-red-800 text-red-300'
            }`}
          >
            {verificationResult.verified ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            )}
            <span>{verificationResult.message}</span>
          </div>
        )}

        {/* Robots.txt Safety Inspector */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-amber-400" />
              Robots.txt Safety & Compliance Check
            </span>
            <span className="text-[11px] font-mono text-emerald-400">
              Crawl-delay: {parsedRobots.crawlDelaySeconds}s enforced
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            AetherLoad automatically checks <code className="text-slate-300">/robots.txt</code>. Disallowed paths ({parsedRobots.disallowedPaths.join(', ')}) will be bypassed to prevent administrative endpoint degradation.
          </p>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
          >
            Dismiss
          </button>
          <button
            onClick={handleRunVerification}
            disabled={isChecking}
            className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold cursor-pointer shadow-md flex items-center gap-1.5 disabled:opacity-50"
          >
            <ShieldCheck className="w-4 h-4" />
            {isChecking ? 'Querying DNS TXT Records...' : 'Verify Ownership Now'}
          </button>
        </div>
      </div>
    </div>
  );
};
