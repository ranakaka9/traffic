import React from 'react';
import {
  ShieldCheck,
  Lock,
  Cpu,
  Layers,
  Zap,
  DollarSign,
  AlertTriangle,
  Server,
  Network,
  CheckCircle2,
} from 'lucide-react';

export const SecurityRoadmap: React.FC = () => {
  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-sky-950 p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono uppercase tracking-wider mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              Compliance, Zero-Trust & Infrastructure Hardening
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Security, Anti-Abuse & Deployment Roadmap
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Multi-tenant container isolation, automated kill-switch mechanics, domain verification compliance,
              and cost-optimized Kubernetes orchestration across worldwide regions.
            </p>
          </div>
        </div>
      </div>

      {/* Grid of Security Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pillar 1: Worker Isolation & Container Sandboxing */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="w-9 h-9 rounded-xl bg-sky-950 border border-sky-800 flex items-center justify-center text-sky-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">1. Worker Sandboxing & Isolation (gVisor)</h2>
              <p className="text-xs text-slate-400">Zero host privilege & ephemeral execution</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Headless Chromium and browser automation execute untrusted web content. To prevent sandbox escapes and
            lateral network movement, worker pods are strictly isolated:
          </p>

          <ul className="text-xs text-slate-300 space-y-2">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">gVisor (runsc) Container Runtime:</strong> Intercepts all syscalls in
                user-space, preventing direct kernel vulnerabilities or escape to host node.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Read-Only Root Filesystem & Non-Root UID:</strong> Worker containers run
                under non-privileged UID 10001 with read-only filesystems and ephemeral memory mounts (tmpfs).
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Calico Egress Network Policies:</strong> Workers are prevented from
                contacting cloud metadata services (169.254.169.254), internal K8s cluster services, or other tenant pods.
              </span>
            </li>
          </ul>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-sky-300">
            <code>securityContext: &#123; runAsNonRoot: true, readOnlyRootFilesystem: true, allowPrivilegeEscalation: false &#125;</code>
          </div>
        </div>

        {/* Pillar 2: Anti-Abuse, Verification & Kill-Switch */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="w-9 h-9 rounded-xl bg-amber-950 border border-amber-800 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">2. Anti-Abuse & Denial-of-Service Defense</h2>
              <p className="text-xs text-slate-400">Compliance safety gate & auto-kill thresholds</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            High-volume synthetic traffic platforms must prevent malicious denial-of-service (DoS) attacks against
            unauthorized targets:
          </p>

          <ul className="text-xs text-slate-300 space-y-2">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Mandatory Domain Verification:</strong> Traffic exceeding 50 VUs requires
                DNS TXT record validation (<code className="text-amber-300">aetherload-verification=token_...</code>) or HTML meta tag.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Automated Circuit Breaker:</strong> If target responses exceed 15% HTTP 5xx
                or 429 Too Many Requests, the run automatically drains to prevent taking the customer's server down.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Robots.txt Crawl-Delay Abide:</strong> Automated crawler parsing respects
                disallow paths and sets minimum intervals between consecutive worker hits.
              </span>
            </li>
          </ul>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-amber-300">
            <code>killSwitch.triggerIf(errorRate5xx &gt; 0.15 || consecutiveFailures &gt; 500)</code>
          </div>
        </div>

        {/* Pillar 3: Kubernetes & KEDA Autoscaling */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-950 border border-indigo-800 flex items-center justify-center text-indigo-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">3. Kubernetes (K8s) & KEDA Elastic Scaling</h2>
              <p className="text-xs text-slate-400">Rapid scale-to-zero and burst capacity</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Worker clusters scale dynamically based on BullMQ queue depth and targeted virtual concurrency:
          </p>

          <ul className="text-xs text-slate-300 space-y-2">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">KEDA Redis ScaledObject:</strong> Scales worker deployments from 0 pods to
                1,000+ pods in seconds based on pending jobs in Redis list or Kafka partition lag.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Pre-Warmed Headless Pool:</strong> Maintains a 5% warm pool of idling
                Chromium browser pods to eliminate cold-start container launch latency.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Graceful Pod Draining:</strong> Pods receive SIGTERM, finish their
                active browser dwell cycle, flush final Kafka metrics, and terminate within 5 seconds.
              </span>
            </li>
          </ul>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-indigo-300">
            <code>apiVersion: keda.sh/v1alpha1 • Kind: ScaledObject • targetAverageValue: "10"</code>
          </div>
        </div>

        {/* Pillar 4: Cost Optimization & Proxy Efficiency */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">4. Cost Optimization & Infrastructure Efficiency</h2>
              <p className="text-xs text-slate-400">70% compute savings & proxy bandwidth reduction</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Running hundreds of thousands of simulated browser sessions can be compute-intensive without strict architectural controls:
          </p>

          <ul className="text-xs text-slate-300 space-y-2">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Spot Instance Fleets:</strong> Worker nodes run on AWS EC2 Spot / GCP
                Preemptible VMs, reducing raw compute billing by up to 72%.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">ARM64 Graviton / Ampere Nodes:</strong> Go HTTP workers run on ARM64 nodes,
                delivering 40% higher requests/watt than standard x86 instances.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
              <span>
                <strong className="text-white">Browser Asset Filtering:</strong> Option to block heavy video, media, and
                fonts in Playwright to save up to 80% proxy data transfer bandwidth costs.
              </span>
            </li>
          </ul>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-emerald-300">
            <code>page.route("**/*.(png|jpg|mp4)", route =&gt; route.abort()) // Save Proxy Bandwidth</code>
          </div>
        </div>
      </div>
    </div>
  );
};
