import React from 'react';
import {
  Settings,
  Flame,
  Layers,
  Globe,
  Smartphone,
  ShieldCheck,
  Zap,
  Clock,
  Gauge,
  Sliders,
  DollarSign,
} from 'lucide-react';
import { ScenarioConfig, ProxyRegionConfig } from '../types';
import { DEVICE_PROFILES, PRESET_SCENARIOS } from '../data/mockData';
import { calculateUsageCredits } from '../lib/simulation-engine';

interface ScenarioBuilderProps {
  scenario: ScenarioConfig;
  onChangeScenario: (updated: ScenarioConfig) => void;
  onLaunch: () => void;
  isSimulating: boolean;
  domainVerified: boolean;
  onOpenVerifyModal: () => void;
}

export const ScenarioBuilder: React.FC<ScenarioBuilderProps> = ({
  scenario,
  onChangeScenario,
  onLaunch,
  isSimulating,
  domainVerified,
  onOpenVerifyModal,
}) => {
  const creditEstimate = calculateUsageCredits({
    durationSeconds: scenario.durationSeconds,
    peakConcurrency: scenario.peakConcurrency,
    proxyTier: scenario.proxyType,
    workerType: scenario.workerType,
  });

  const handleSelectPreset = (presetId: string) => {
    const found = PRESET_SCENARIOS.find((p) => p.id === presetId);
    if (found) {
      onChangeScenario({ ...found });
    }
  };

  const handleToggleRegion = (regionId: string) => {
    const updated = scenario.regions.map((r) =>
      r.id === regionId ? { ...r, selected: !r.selected } : r
    );
    onChangeScenario({ ...scenario, regions: updated });
  };

  const handleDeviceWeightChange = (profileId: string, weightPct: number) => {
    const updated = scenario.deviceMix.map((d) =>
      d.profileId === profileId ? { ...d, weightPct } : d
    );
    onChangeScenario({ ...scenario, deviceMix: updated });
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6 text-slate-100">
      {/* Preset Scenario Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-400" />
            Traffic Scenario Configuration
          </h2>
          <p className="text-xs text-slate-400">
            Select a verified simulation scenario or customize concurrency curves, devices, and geo-proxies.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Presets:</span>
          <div className="flex flex-wrap gap-1.5">
            {PRESET_SCENARIOS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleSelectPreset(preset.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                  scenario.id === preset.id
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {preset.name.split(' ')[0]} {preset.name.split(' ')[1]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Target URL & Engine Selection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Target URL with Domain Verification Badge */}
        <div className="lg:col-span-2 space-y-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Target Endpoint URL</span>
            {domainVerified ? (
              <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-mono font-medium">
                <ShieldCheck className="w-3.5 h-3.5" />
                Domain Verified (DNS TXT Match)
              </span>
            ) : (
              <button
                onClick={onOpenVerifyModal}
                className="inline-flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-mono cursor-pointer underline"
              >
                Domain Unverified - Click to Verify
              </button>
            )}
          </label>
          <div className="relative">
            <input
              type="url"
              value={scenario.targetUrl}
              onChange={(e) => onChangeScenario({ ...scenario, targetUrl: e.target.value })}
              placeholder="https://your-domain.com/path"
              className="w-full bg-slate-950 border border-slate-800 focus:border-sky-500 rounded-xl px-4 py-2.5 text-xs font-mono text-white placeholder-slate-600 focus:outline-none"
            />
          </div>
        </div>

        {/* Worker Engine Type */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Worker Engine Cluster</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onChangeScenario({ ...scenario, workerType: 'playwright_browser' })}
              className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                scenario.workerType === 'playwright_browser'
                  ? 'bg-sky-950/80 border-sky-400 ring-1 ring-sky-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="font-semibold text-xs flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-sky-400" />
                Playwright DOM
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Full JS, LCP, Scrolls</div>
            </button>

            <button
              onClick={() => onChangeScenario({ ...scenario, workerType: 'go_http' })}
              className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                scenario.workerType === 'go_http'
                  ? 'bg-sky-950/80 border-sky-400 ring-1 ring-sky-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="font-semibold text-xs flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                Go HTTP Flood
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">High RPS, Low CPU</div>
            </button>
          </div>
        </div>
      </div>

      {/* Concurrency Curve, VUs & Duration */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800">
        {/* Pattern Curve */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Gauge className="w-3.5 h-3.5 text-sky-400" />
            Concurrency Curve
          </label>
          <select
            value={scenario.pattern}
            onChange={(e) =>
              onChangeScenario({ ...scenario, pattern: e.target.value as ScenarioConfig['pattern'] })
            }
            className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500 cursor-pointer"
          >
            <option value="ramp">Linear Ramp-Up & Ramp-Down</option>
            <option value="spike">Violent Traffic Spike</option>
            <option value="steady">Steady Sustained Soak</option>
            <option value="step">Stepped Stairs (25% Increments)</option>
          </select>
        </div>

        {/* Peak Concurrency VUs */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <label className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              Peak Concurrency (VUs)
            </label>
            <span className="font-mono text-sky-300 font-bold">
              {scenario.peakConcurrency.toLocaleString()} VUs
            </span>
          </div>
          <input
            type="range"
            min="50"
            max="15000"
            step="50"
            value={scenario.peakConcurrency}
            onChange={(e) =>
              onChangeScenario({ ...scenario, peakConcurrency: parseInt(e.target.value, 10) })
            }
            className="w-full accent-sky-500 cursor-pointer"
          />
        </div>

        {/* Duration Seconds */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <label className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              Execution Duration
            </label>
            <span className="font-mono text-sky-300 font-bold">{scenario.durationSeconds}s</span>
          </div>
          <input
            type="range"
            min="15"
            max="300"
            step="5"
            value={scenario.durationSeconds}
            onChange={(e) =>
              onChangeScenario({ ...scenario, durationSeconds: parseInt(e.target.value, 10) })
            }
            className="w-full accent-indigo-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Device Emulation Distribution & Proxy Tiers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Device Profile Weight Allocation */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-sky-400" />
              Device Profile Emulation Distribution
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Windows, iOS, Android</span>
          </div>

          <div className="space-y-2.5">
            {DEVICE_PROFILES.slice(0, 4).map((profile) => {
              const currentWeight =
                scenario.deviceMix.find((d) => d.profileId === profile.id)?.weightPct || 0;
              return (
                <div key={profile.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-300">{profile.name}</span>
                    <span className="font-mono text-sky-400 font-semibold">{currentWeight}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={currentWeight}
                    onChange={(e) =>
                      handleDeviceWeightChange(profile.id, parseInt(e.target.value, 10))
                    }
                    className="w-full accent-sky-500 cursor-pointer"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Proxy Routing & Geo Pools */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              Geo-Targeting & Proxy Network Layer
            </h3>
            <div className="flex items-center gap-1 text-[11px] font-mono">
              {(['datacenter', 'residential', 'mobile'] as const).map((tier) => (
                <button
                  key={tier}
                  onClick={() => onChangeScenario({ ...scenario, proxyType: tier })}
                  className={`px-2 py-0.5 rounded capitalize cursor-pointer transition ${
                    scenario.proxyType === tier
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {tier}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {scenario.regions.map((region) => (
              <button
                key={region.id}
                onClick={() => handleToggleRegion(region.id)}
                className={`p-2.5 rounded-lg border text-left transition cursor-pointer ${
                  region.selected
                    ? 'bg-emerald-950/40 border-emerald-500/80 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">
                    {region.flag} {region.name.split(' ')[0]}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400">
                    {region.datacenterLatMs}ms RTT
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 mt-1 font-mono">
                  {(region.availableIps / 1000).toFixed(0)}k Exit IPs
                </div>
              </button>
            ))}
          </div>

          {/* Behavioral Controls */}
          <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">Simulated Bounce Rate</span>
              <span className="font-mono text-slate-200">{scenario.bounceRatePct}% single-page</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Target Scroll Depth</span>
              <span className="font-mono text-slate-200">{scenario.scrollDepthPct}% DOM height</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Footer & Cost Metering Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2 text-xs font-mono">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="text-slate-400 block text-[10px]">ESTIMATED RUN USAGE</span>
              <span className="text-white font-bold">
                {creditEstimate.creditsDeducted.toLocaleString()} Credits (~$
                {creditEstimate.estimatedCostUsd.toFixed(2)})
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
            <span>Safety: Auto-kill if 5xx &gt; {scenario.safetyKillOn5xxPct}%</span>
          </div>
        </div>

        <button
          onClick={onLaunch}
          disabled={isSimulating}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-sm transition cursor-pointer shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <Flame className="w-4 h-4 fill-current text-amber-300" />
          {isSimulating ? 'Simulation in Progress...' : 'Launch Synthetic Load Run'}
        </button>
      </div>
    </div>
  );
};
