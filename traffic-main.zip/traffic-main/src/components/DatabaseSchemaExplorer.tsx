import React, { useState } from 'react';
import { Database, Copy, Check, Table, Key, Binary, FileCode2, Layers } from 'lucide-react';
import { DATABASE_SCHEMA_SQL } from '../data/mockData';

interface TableDef {
  name: string;
  description: string;
  columns: Array<{ name: string; type: string; constraints: string; desc: string }>;
  indexes: string[];
}

const TABLES: TableDef[] = [
  {
    name: 'users',
    description: 'Stores platform engineers, organization association, RBAC roles, and hashed API keys.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY, DEFAULT gen_random_uuid()', desc: 'Unique account identifier' },
      { name: 'organization_id', type: 'UUID', constraints: 'NOT NULL, REFERENCES organizations(id)', desc: 'Tenancy boundary' },
      { name: 'email', type: 'VARCHAR(255)', constraints: 'UNIQUE, NOT NULL', desc: 'Login & notification email' },
      { name: 'role', type: 'user_role', constraints: 'NOT NULL, DEFAULT "engineer"', desc: 'super_admin | org_admin | engineer' },
      { name: 'api_key_hash', type: 'VARCHAR(64)', constraints: 'UNIQUE', desc: 'SHA-256 hash of API credentials' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'NOT NULL, DEFAULT NOW()', desc: 'Account registration time' },
    ],
    indexes: ['CREATE UNIQUE INDEX idx_users_email ON users(email);', 'CREATE INDEX idx_users_org ON users(organization_id);'],
  },
  {
    name: 'subscriptions',
    description: 'Tiered billing records, Stripe customer pointers, concurrency thread limits, and credit balances.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY', desc: 'Subscription record identifier' },
      { name: 'organization_id', type: 'UUID', constraints: 'UNIQUE, NOT NULL, REFERENCES organizations', desc: 'Org link' },
      { name: 'tier', type: 'subscription_tier', constraints: 'NOT NULL DEFAULT "free"', desc: 'free | pro | enterprise' },
      { name: 'max_concurrent_vus', type: 'INTEGER', constraints: 'NOT NULL DEFAULT 50', desc: 'Free: 50, Pro: 10k, Ent: 100k' },
      { name: 'allowed_proxy_types', type: 'VARCHAR(50)[]', constraints: 'NOT NULL DEFAULT {"datacenter"}', desc: 'datacenter | residential | mobile' },
      { name: 'monthly_compute_credits', type: 'BIGINT', constraints: 'NOT NULL DEFAULT 10000', desc: 'Allocated credit allowance' },
      { name: 'used_credits_current_cycle', type: 'BIGINT', constraints: 'NOT NULL DEFAULT 0', desc: 'Metered usage' },
    ],
    indexes: ['CREATE INDEX idx_subscriptions_tier ON subscriptions(tier);', 'CREATE UNIQUE INDEX idx_subs_stripe_cust ON subscriptions(stripe_customer_id);'],
  },
  {
    name: 'traffic_scenarios',
    description: 'Configurable test definitions: URL, concurrency curves, device mix, and safety kill thresholds.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY', desc: 'Scenario unique identifier' },
      { name: 'organization_id', type: 'UUID', constraints: 'NOT NULL, REFERENCES organizations', desc: 'Tenancy boundary' },
      { name: 'name', type: 'VARCHAR(255)', constraints: 'NOT NULL', desc: 'Human-readable test name' },
      { name: 'target_url', type: 'TEXT', constraints: 'NOT NULL', desc: 'FQDN & path to test' },
      { name: 'worker_type', type: 'worker_engine', constraints: 'NOT NULL', desc: 'go_http | playwright_browser' },
      { name: 'pattern', type: 'traffic_pattern_type', constraints: 'NOT NULL', desc: 'ramp | steady | spike | step' },
      { name: 'peak_concurrency_vus', type: 'INTEGER', constraints: 'NOT NULL CHECK (> 0)', desc: 'Max concurrent virtual users' },
      { name: 'duration_seconds', type: 'INTEGER', constraints: 'NOT NULL', desc: 'Run execution window' },
      { name: 'proxy_type', type: 'VARCHAR(20)', constraints: 'NOT NULL', desc: 'datacenter | residential | mobile' },
      { name: 'device_mix', type: 'JSONB', constraints: 'NOT NULL DEFAULT "[]"', desc: 'Array of device profile IDs & weights' },
      { name: 'safety_kill_5xx_threshold_pct', type: 'NUMERIC(4,1)', constraints: 'DEFAULT 15.0', desc: 'Auto-kill threshold if server collapses' },
    ],
    indexes: ['CREATE INDEX idx_scenarios_org ON traffic_scenarios(organization_id);', 'CREATE INDEX idx_scenarios_target ON traffic_scenarios(target_url);'],
  },
  {
    name: 'device_profiles',
    description: 'Emulation catalog for desktop, mobile, and tablet browser fingerprints and Client Hints.',
    columns: [
      { name: 'id', type: 'VARCHAR(50)', constraints: 'PRIMARY KEY', desc: 'Profile slug (e.g. win11-chrome, ios18-safari)' },
      { name: 'name', type: 'VARCHAR(100)', constraints: 'NOT NULL', desc: 'Display name' },
      { name: 'category', type: 'VARCHAR(20)', constraints: 'CHECK IN (desktop, mobile, tablet)', desc: 'Device class' },
      { name: 'viewport_width', type: 'INTEGER', constraints: 'NOT NULL', desc: 'CSS viewport width' },
      { name: 'viewport_height', type: 'INTEGER', constraints: 'NOT NULL', desc: 'CSS viewport height' },
      { name: 'user_agent', type: 'TEXT', constraints: 'NOT NULL', desc: 'Exact User-Agent string' },
      { name: 'client_hints_json', type: 'JSONB', constraints: 'NOT NULL', desc: 'Sec-CH-UA, Platform, Brands' },
    ],
    indexes: ['CREATE INDEX idx_device_cat ON device_profiles(category);'],
  },
  {
    name: 'worker_jobs',
    description: 'Tracks orchestrated distributed worker pods across global K8s clusters during run execution.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY', desc: 'Execution run identifier' },
      { name: 'scenario_id', type: 'UUID', constraints: 'NOT NULL, REFERENCES traffic_scenarios', desc: 'Scenario link' },
      { name: 'status', type: 'job_status', constraints: 'NOT NULL DEFAULT "queued"', desc: 'queued | provisioning | running | completed | killed' },
      { name: 'assigned_cluster_id', type: 'VARCHAR(64)', constraints: 'NOT NULL', desc: 'Target K8s cluster identifier' },
      { name: 'total_requests_dispatched', type: 'BIGINT', constraints: 'NOT NULL DEFAULT 0', desc: 'Cumulative HTTP requests' },
      { name: 'avg_ttfb_ms', type: 'NUMERIC(7,2)', constraints: 'DEFAULT 0', desc: 'Average time to first byte' },
      { name: 'p95_ttfb_ms', type: 'NUMERIC(7,2)', constraints: 'DEFAULT 0', desc: '95th percentile TTFB' },
      { name: 'kill_reason', type: 'TEXT', constraints: 'NULLABLE', desc: 'Manual or automated kill-switch trigger' },
    ],
    indexes: ['CREATE INDEX idx_worker_jobs_org_status ON worker_jobs(organization_id, status);', 'CREATE INDEX idx_worker_jobs_scenario ON worker_jobs(scenario_id);'],
  },
  {
    name: 'usage_metrics',
    description: 'High-throughput time-series metric snapshots ingested into TimescaleDB / ClickHouse.',
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY (id, timestamp)', desc: 'Partitioned composite primary key' },
      { name: 'job_id', type: 'UUID', constraints: 'NOT NULL, REFERENCES worker_jobs', desc: 'Job correlation' },
      { name: 'timestamp', type: 'TIMESTAMPTZ', constraints: 'NOT NULL', desc: '1-second aggregation epoch' },
      { name: 'active_vus', type: 'INTEGER', constraints: 'NOT NULL', desc: 'Concurrent active virtual users' },
      { name: 'instantaneous_rps', type: 'INTEGER', constraints: 'NOT NULL', desc: 'Requests per second' },
      { name: 'error_5xx_count_interval', type: 'INTEGER', constraints: 'NOT NULL DEFAULT 0', desc: 'Failed responses' },
      { name: 'p95_ttfb_ms', type: 'NUMERIC(6,2)', constraints: 'NOT NULL', desc: 'Tail latency' },
      { name: 'cdn_cache_hit_ratio', type: 'NUMERIC(4,3)', constraints: 'NOT NULL', desc: 'HIT vs MISS ratio (0.0 - 1.0)' },
    ],
    indexes: ['CREATE INDEX idx_usage_metrics_job_time ON usage_metrics(job_id, timestamp DESC);', 'CREATE INDEX idx_usage_metrics_scenario_time ON usage_metrics(scenario_id, timestamp DESC);'],
  },
];

export const DatabaseSchemaExplorer: React.FC = () => {
  const [selectedTable, setSelectedTable] = useState<string>('traffic_scenarios');
  const [viewMode, setViewMode] = useState<'tables' | 'raw_sql'>('tables');
  const [copied, setCopied] = useState<boolean>(false);

  const activeTable = TABLES.find((t) => t.name === selectedTable) || TABLES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(DATABASE_SCHEMA_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-sky-950 p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono uppercase tracking-wider mb-2">
              <Database className="w-3.5 h-3.5" />
              Relational & Time-Series Data Layer
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Database Schema & Metrics Storage Design
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              PostgreSQL 16 relational architecture for tenancy, billing, and scenarios paired with
              TimescaleDB hypertable / ClickHouse columnar storage for high-frequency load telemetry.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode(viewMode === 'tables' ? 'raw_sql' : 'tables')}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 transition cursor-pointer flex items-center gap-1.5"
            >
              <FileCode2 className="w-3.5 h-3.5 text-sky-400" />
              {viewMode === 'tables' ? 'View Raw SQL DDL' : 'View Table Explorer'}
            </button>
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-xs font-medium text-white transition cursor-pointer flex items-center gap-1.5 shadow-md"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied DDL' : 'Copy All SQL'}
            </button>
          </div>
        </div>
      </div>

      {viewMode === 'raw_sql' ? (
        /* Raw SQL Editor View */
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400">schema.sql • PostgreSQL 16 + TimescaleDB Extension</span>
            <span className="text-xs text-emerald-400 font-mono">Verified DDL Syntax</span>
          </div>
          <pre className="bg-slate-950 p-5 rounded-xl border border-slate-800/80 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed max-h-[650px] overflow-y-auto">
            {DATABASE_SCHEMA_SQL}
          </pre>
        </div>
      ) : (
        /* Interactive Table Explorer */
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Table List Sidebar */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 shadow-xl space-y-2">
            <h3 className="text-xs font-mono uppercase text-slate-400 font-bold px-2 py-1">
              Database Tables ({TABLES.length})
            </h3>
            <div className="space-y-1">
              {TABLES.map((table) => (
                <button
                  key={table.name}
                  onClick={() => setSelectedTable(table.name)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono transition cursor-pointer flex items-center justify-between ${
                    selectedTable === table.name
                      ? 'bg-sky-600 text-white font-semibold shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Table className="w-3.5 h-3.5 shrink-0" />
                    {table.name}
                  </span>
                  <span className="text-[10px] opacity-70">{table.columns.length} cols</span>
                </button>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-2 px-2">
              <div className="font-semibold text-slate-200">High-Throughput Partitioning:</div>
              <p>
                <code className="text-sky-300">usage_metrics</code> is converted into a hypertable chunked
                by 1-hour time intervals to sustain &gt;100k rows/second ingest without index degradation.
              </p>
            </div>
          </div>

          {/* Table Details */}
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800 font-bold">
                    Table
                  </span>
                  <h2 className="text-xl font-bold font-mono text-white">{activeTable.name}</h2>
                </div>
                <p className="text-xs text-slate-300 mt-2">{activeTable.description}</p>
              </div>

              {/* Columns Table */}
              <div>
                <h3 className="text-xs font-mono uppercase text-slate-400 font-bold mb-3 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-sky-400" />
                  Column Definitions & Constraints
                </h3>

                <div className="overflow-x-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 font-mono border-b border-slate-800">
                      <tr>
                        <th className="p-3">Column</th>
                        <th className="p-3">Data Type</th>
                        <th className="p-3">Constraints</th>
                        <th className="p-3">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 bg-slate-900/50">
                      {activeTable.columns.map((col) => (
                        <tr key={col.name} className="hover:bg-slate-800/30">
                          <td className="p-3 font-mono font-semibold text-sky-300 flex items-center gap-1.5">
                            {col.constraints.includes('PRIMARY') ? (
                              <Key className="w-3 h-3 text-amber-400" />
                            ) : null}
                            {col.name}
                          </td>
                          <td className="p-3 font-mono text-indigo-300">{col.type}</td>
                          <td className="p-3 font-mono text-slate-400 text-[11px]">{col.constraints}</td>
                          <td className="p-3 text-slate-300">{col.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Indexes */}
              <div>
                <h3 className="text-xs font-mono uppercase text-slate-400 font-bold mb-2 flex items-center gap-1.5">
                  <Binary className="w-3.5 h-3.5 text-emerald-400" />
                  Indexes & Query Optimization
                </h3>
                <div className="space-y-1.5">
                  {activeTable.indexes.map((idx, i) => (
                    <div
                      key={i}
                      className="text-xs font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-emerald-300"
                    >
                      {idx}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
