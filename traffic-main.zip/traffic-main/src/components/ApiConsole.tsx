import React, { useState } from 'react';
import { Terminal, Send, CheckCircle2, Copy, Check, ShieldCheck, Flame, Cpu } from 'lucide-react';
import { OPENAPI_SWAGGER_SPEC } from '../data/mockData';

interface ApiEndpoint {
  method: 'GET' | 'POST' | 'DELETE';
  path: string;
  summary: string;
  description: string;
  sampleBody?: string;
  sampleResponse: {
    status: number;
    body: any;
  };
}

const ENDPOINTS: ApiEndpoint[] = [
  {
    method: 'POST',
    path: '/v1/runs',
    summary: 'Dispatch Synthetic Load Run',
    description: 'Enqueues load job into regional BullMQ queue; KEDA provisions worker pods based on concurrency curve.',
    sampleBody: JSON.stringify(
      {
        scenarioId: '8f72c91a-b34e-41d5-bc48-d3625b18aa21',
        overrideConcurrency: 5000,
        dryRun: false,
      },
      null,
      2
    ),
    sampleResponse: {
      status: 202,
      body: {
        jobId: 'run_78c2e91f041b',
        status: 'provisioning',
        assignedClusters: ['k8s-us-east-pool-01', 'k8s-eu-central-pool-02'],
        allocatedWorkerPods: 25,
        estimatedCreditsBilled: 4200,
        telemetryStreamUrl: 'https://api.aetherload.dev/v1/runs/run_78c2e91f041b/metrics/realtime',
        createdAt: new Date().toISOString(),
      },
    },
  },
  {
    method: 'POST',
    path: '/v1/runs/run_78c2e91f041b/kill',
    summary: 'Emergency Kill-Switch Trigger',
    description: 'Instantly broadcasts abort signal across worker pods and gracefully terminates proxy sockets within 250ms.',
    sampleBody: JSON.stringify(
      {
        reason: 'Operator manual abort: Target origin latency exceeded SLA threshold',
      },
      null,
      2
    ),
    sampleResponse: {
      status: 200,
      body: {
        jobId: 'run_78c2e91f041b',
        status: 'killed',
        stoppedAt: new Date().toISOString(),
        activeWorkersRemaining: 0,
        drainedConnections: 4892,
        totalRequestsCompleted: 38210,
      },
    },
  },
  {
    method: 'GET',
    path: '/v1/workers/health',
    summary: 'Cluster & Proxy Health Status',
    description: 'Queries capacity, latency, and available IP count across all distributed worker clusters.',
    sampleResponse: {
      status: 200,
      body: {
        clusterStatus: 'operational',
        timestamp: new Date().toISOString(),
        clusters: [
          { id: 'k8s-us-east-01', region: 'us-east', activePods: 140, maxPods: 500, cpuUtilizationPct: 42.1 },
          { id: 'k8s-eu-central-01', region: 'eu-central', activePods: 90, maxPods: 400, cpuUtilizationPct: 36.8 },
          { id: 'k8s-ap-east-01', region: 'ap-east', activePods: 65, maxPods: 300, cpuUtilizationPct: 29.4 },
        ],
        proxyPools: [
          { type: 'residential', availableIps: 2450000, avgEgressLatencyMs: 48.2, healthScore: 0.998 },
          { type: 'mobile_5g', availableIps: 890000, avgEgressLatencyMs: 76.5, healthScore: 0.994 },
          { type: 'datacenter', availableIps: 450000, avgEgressLatencyMs: 24.1, healthScore: 1.0 },
        ],
      },
    },
  },
  {
    method: 'GET',
    path: '/v1/runs/run_78c2e91f041b/metrics/realtime',
    summary: 'Real-Time Telemetry Stream (SSE)',
    description: 'Server-Sent Events endpoint streaming 1-second rolling percentiles and status counters.',
    sampleResponse: {
      status: 200,
      body: {
        event: 'telemetry_tick',
        data: {
          timestamp: new Date().toISOString(),
          activeVUs: 4850,
          currentRps: 11240,
          statusCodes: { '200': 10890, '304': 240, '429': 18, '500': 2 },
          latency: { p50: 38.4, p95: 86.1, p99: 142.3, avg: 44.2 },
          cdnCacheHitRatio: 0.912,
          bandwidthMbps: 184.6,
        },
      },
    },
  },
  {
    method: 'POST',
    path: '/v1/domains/verify',
    summary: 'Verify Domain Ownership (Safety Gate)',
    description: 'Validates published DNS TXT record or HTML meta tag before allowing high-concurrency tests.',
    sampleBody: JSON.stringify(
      {
        domain: 'example.com',
        verificationMethod: 'dns_txt',
      },
      null,
      2
    ),
    sampleResponse: {
      status: 200,
      body: {
        domain: 'example.com',
        verified: true,
        method: 'dns_txt',
        expectedRecord: 'aetherload-verification=token_e8a1f8c4',
        verifiedAt: new Date().toISOString(),
        robotsTxtStatus: {
          parsed: true,
          crawlDelaySeconds: 2.0,
          disallowedCount: 3,
        },
      },
    },
  },
];

export const ApiConsole: React.FC = () => {
  const [selectedIdx, setSelectedIdx] = useState<number>(0);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [liveResponse, setLiveResponse] = useState<any>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const endpoint = ENDPOINTS[selectedIdx];

  const handleTestEndpoint = () => {
    setIsExecuting(true);
    setLiveResponse(null);

    setTimeout(() => {
      setLiveResponse(endpoint.sampleResponse);
      setIsExecuting(false);
    }, 450);
  };

  const handleCopySpec = () => {
    navigator.clipboard.writeText(JSON.stringify(OPENAPI_SWAGGER_SPEC, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-sky-950 p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono uppercase tracking-wider mb-2">
              <Terminal className="w-3.5 h-3.5" />
              REST API & OpenAPI 3.1 Specification
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              API Endpoints & Swagger Console
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Integrate synthetic load testing into CI/CD pipelines (GitHub Actions, GitLab CI, Terraform) with
              standard RESTful endpoints, API keys, and real-time SSE streaming.
            </p>
          </div>

          <button
            onClick={handleCopySpec}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition cursor-pointer flex items-center gap-1.5 border border-slate-700 shrink-0"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied OpenAPI JSON' : 'Export OpenAPI 3.1 Spec'}
          </button>
        </div>
      </div>

      {/* Main Console Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Endpoint Selector Sidebar */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 shadow-xl space-y-2">
          <h3 className="text-xs font-mono uppercase text-slate-400 font-bold px-2 py-1">
            API Endpoints ({ENDPOINTS.length})
          </h3>
          <div className="space-y-1.5">
            {ENDPOINTS.map((ep, idx) => {
              const active = selectedIdx === idx;
              return (
                <button
                  key={ep.path + ep.method}
                  onClick={() => {
                    setSelectedIdx(idx);
                    setLiveResponse(null);
                  }}
                  className={`w-full text-left p-3 rounded-xl transition cursor-pointer border ${
                    active
                      ? 'bg-sky-950/80 border-sky-400 text-white shadow-sm'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                        ep.method === 'POST'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-sky-950 text-sky-400 border border-sky-800'
                      }`}
                    >
                      {ep.method}
                    </span>
                    <span className="font-mono text-xs font-semibold truncate text-slate-200">
                      {ep.path}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{ep.summary}</p>
                </button>
              );
            })}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-2 px-2">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
              Authentication Header
            </div>
            <code className="block bg-slate-950 p-2 rounded text-[11px] font-mono text-sky-300 border border-slate-800">
              Authorization: Bearer aether_live_...
            </code>
          </div>
        </div>

        {/* Endpoint Inspector & Runner */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                      endpoint.method === 'POST'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-sky-950 text-sky-400 border border-sky-800'
                    }`}
                  >
                    {endpoint.method}
                  </span>
                  <span className="text-base font-mono font-bold text-white">{endpoint.path}</span>
                </div>
                <p className="text-xs text-slate-300 mt-1">{endpoint.description}</p>
              </div>

              <button
                onClick={handleTestEndpoint}
                disabled={isExecuting}
                className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium transition cursor-pointer flex items-center gap-1.5 shadow-md disabled:opacity-50 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                {isExecuting ? 'Sending Request...' : 'Send Test Request'}
              </button>
            </div>

            {/* Request Payload Section */}
            {endpoint.sampleBody && (
              <div>
                <h4 className="text-xs font-mono uppercase text-slate-400 font-bold mb-2">
                  Request JSON Body (Payload)
                </h4>
                <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto">
                  {endpoint.sampleBody}
                </pre>
              </div>
            )}

            {/* Response Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-mono uppercase text-slate-400 font-bold">
                  Simulated API Response
                </h4>
                {liveResponse && (
                  <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    HTTP {liveResponse.status} OK (34ms roundtrip)
                  </span>
                )}
              </div>

              <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono text-emerald-400 overflow-x-auto max-h-72 overflow-y-auto">
                {liveResponse
                  ? JSON.stringify(liveResponse.body, null, 2)
                  : JSON.stringify(endpoint.sampleResponse.body, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
