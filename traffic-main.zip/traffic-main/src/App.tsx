/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Navbar, NavTab } from './components/Navbar';
import { ArchitectureViewer } from './components/ArchitectureViewer';
import { DatabaseSchemaExplorer } from './components/DatabaseSchemaExplorer';
import { WorkerCodeInspector } from './components/WorkerCodeInspector';
import { ApiConsole } from './components/ApiConsole';
import { SecurityRoadmap } from './components/SecurityRoadmap';
import { ScenarioBuilder } from './components/ScenarioBuilder';
import { LiveTelemetryDashboard } from './components/LiveTelemetryDashboard';
import { DomainVerificationModal } from './components/DomainVerificationModal';
import { BillingCalculatorModal } from './components/BillingCalculatorModal';

import {
  ScenarioConfig,
  SimulationTelemetry,
  SimulationLogEntry,
  SaaSUser,
  SaaSPlanTier,
} from './types';
import { PRESET_SCENARIOS, INITIAL_USER, DEVICE_PROFILES } from './data/mockData';
import { calculateConcurrencyAtSecond, calculateUsageCredits } from './lib/simulation-engine';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('simulator');
  const [user, setUser] = useState<SaaSUser>(INITIAL_USER);
  const [scenario, setScenario] = useState<ScenarioConfig>(PRESET_SCENARIOS[0]);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [domainVerified, setDomainVerified] = useState<boolean>(true);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState<boolean>(false);
  const [isBillingModalOpen, setIsBillingModalOpen] = useState<boolean>(false);

  const [telemetry, setTelemetry] = useState<SimulationTelemetry>({
    elapsedSeconds: 0,
    activeVUs: 0,
    currentRps: 0,
    totalRequests: 0,
    statusCodes: { '200': 0, '304': 0, '429': 0, '500': 0, '503': 0 },
    latency: { p50: 32.0, p95: 78.4, p99: 135.2, avg: 41.5 },
    cdnCache: { hitRatio: 0.92, hits: 0, misses: 0 },
    bandwidthMbps: 0,
    activeWorkers: 0,
    isKilled: false,
    logs: [],
  });

  const timerRef = useRef<any>(null);

  // Check URL query parameters for ?autostart=1
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      handleLaunchSimulation();
    }
  }, []);

  // Main Live Simulation Clock Tick
  useEffect(() => {
    if (!isSimulating) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTelemetry((prev) => {
        const nextElapsed = prev.elapsedSeconds + 1;

        if (nextElapsed > scenario.durationSeconds) {
          setIsSimulating(false);
          clearInterval(timerRef.current);
          return {
            ...prev,
            elapsedSeconds: scenario.durationSeconds,
            activeVUs: 0,
            currentRps: 0,
          };
        }

        const vus = calculateConcurrencyAtSecond(
          nextElapsed,
          scenario.durationSeconds,
          scenario.peakConcurrency,
          scenario.pattern
        );

        // Throughput multiplier based on worker engine
        const rpsPerVu =
          scenario.workerType === 'go_http'
            ? 3.5 + Math.random() * 1.5
            : 0.8 + Math.random() * 0.4;
        const currentRps = Math.round(vus * rpsPerVu);
        const newRequests = Math.max(1, currentRps);

        // Status code distribution simulation
        const successCount = Math.round(newRequests * 0.978);
        const cache304Count = Math.round(newRequests * 0.018);
        const rateLimitCount = Math.round(newRequests * 0.003);
        const serverErrorCount = Math.round(newRequests * 0.001);

        const hits = Math.round(newRequests * 0.91);
        const misses = newRequests - hits;

        // Realistic tail latency fluctuations
        const latencyFactor = vus / scenario.peakConcurrency;
        const p50 = Math.round(28 + latencyFactor * 14 + Math.random() * 5);
        const p95 = Math.round(65 + latencyFactor * 32 + Math.random() * 10);
        const p99 = Math.round(110 + latencyFactor * 45 + Math.random() * 15);

        // Bandwidth calculation (average page / API payload size: 38KB)
        const bandwidthMbps = Number(((currentRps * 38 * 8) / 1024).toFixed(1));

        // Generate dynamic worker log entries
        const activeRegions = scenario.regions.filter((r) => r.selected);
        const randomRegion =
          activeRegions[Math.floor(Math.random() * activeRegions.length)] || scenario.regions[0];
        const randomDevice =
          DEVICE_PROFILES[Math.floor(Math.random() * DEVICE_PROFILES.length)];
        const workerId = `pod-${randomRegion.id}-${Math.floor(100 + Math.random() * 900)}`;

        const newLog: SimulationLogEntry = {
          id: `log-${Date.now()}-${Math.random()}`,
          timestamp: new Date().toLocaleTimeString(),
          region: randomRegion.code,
          workerId,
          device: randomDevice.name.split(' (')[0],
          ip: `198.51.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          method: 'GET',
          path: new URL(scenario.targetUrl).pathname || '/',
          status: serverErrorCount > 0 && Math.random() > 0.8 ? 503 : 200,
          ttfbMs: p50 + Math.floor(Math.random() * 15),
          cacheStatus: Math.random() > 0.15 ? 'HIT' : 'MISS',
        };

        return {
          elapsedSeconds: nextElapsed,
          activeVUs: vus,
          currentRps,
          totalRequests: prev.totalRequests + newRequests,
          statusCodes: {
            '200': prev.statusCodes['200'] + successCount,
            '304': prev.statusCodes['304'] + cache304Count,
            '429': prev.statusCodes['429'] + rateLimitCount,
            '500': prev.statusCodes['500'] + serverErrorCount,
            '503': prev.statusCodes['503'],
          },
          latency: {
            p50,
            p95,
            p99,
            avg: Math.round((p50 + p95) / 2),
          },
          cdnCache: {
            hitRatio: Number(((prev.cdnCache.hits + hits) / (prev.totalRequests + newRequests)).toFixed(3)),
            hits: prev.cdnCache.hits + hits,
            misses: prev.cdnCache.misses + misses,
          },
          bandwidthMbps,
          activeWorkers: Math.max(1, Math.ceil(vus / 100)),
          isKilled: false,
          logs: [newLog, ...prev.logs.slice(0, 19)],
        };
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isSimulating, scenario]);

  const handleLaunchSimulation = () => {
    // Calculate and deduct credits
    const cost = calculateUsageCredits({
      durationSeconds: scenario.durationSeconds,
      peakConcurrency: scenario.peakConcurrency,
      proxyTier: scenario.proxyType,
      workerType: scenario.workerType,
    });

    setUser((prev) => ({
      ...prev,
      creditsRemaining: Math.max(0, prev.creditsRemaining - cost.creditsDeducted),
    }));

    setTelemetry({
      elapsedSeconds: 0,
      activeVUs: 1,
      currentRps: 10,
      totalRequests: 0,
      statusCodes: { '200': 0, '304': 0, '429': 0, '500': 0, '503': 0 },
      latency: { p50: 28, p95: 64, p99: 115, avg: 35 },
      cdnCache: { hitRatio: 0.92, hits: 0, misses: 0 },
      bandwidthMbps: 0.5,
      activeWorkers: Math.max(1, Math.ceil(scenario.peakConcurrency / 100)),
      isKilled: false,
      logs: [],
    });

    setIsSimulating(true);
    setCurrentTab('simulator');
  };

  const handleKillSwitch = () => {
    setIsSimulating(false);
    if (timerRef.current) clearInterval(timerRef.current);

    setTelemetry((prev) => ({
      ...prev,
      activeVUs: 0,
      currentRps: 0,
      isKilled: true,
      killReason: 'Operator triggered Emergency Kill-Switch: Graceful worker drain completed.',
      logs: [
        {
          id: `kill-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          region: 'GLOBAL',
          workerId: 'ORCHESTRATOR',
          device: 'System',
          ip: '0.0.0.0',
          method: 'ABORT',
          path: '/emergency-kill',
          status: 499,
          ttfbMs: 0,
          cacheStatus: 'BYPASS',
        },
        ...prev.logs,
      ],
    }));
  };

  const handleResetSimulation = () => {
    setIsSimulating(false);
    setTelemetry({
      elapsedSeconds: 0,
      activeVUs: 0,
      currentRps: 0,
      totalRequests: 0,
      statusCodes: { '200': 0, '304': 0, '429': 0, '500': 0, '503': 0 },
      latency: { p50: 32, p95: 78, p99: 135, avg: 41 },
      cdnCache: { hitRatio: 0.92, hits: 0, misses: 0 },
      bandwidthMbps: 0,
      activeWorkers: 0,
      isKilled: false,
      logs: [],
    });
  };

  const handleSelectTier = (tier: SaaSPlanTier) => {
    setUser((prev) => ({
      ...prev,
      tier,
      maxConcurrency: tier === 'free' ? 50 : tier === 'pro' ? 10000 : 100000,
      creditsRemaining:
        tier === 'free' ? 5000 : tier === 'pro' ? 500000 : 5000000,
    }));
    setIsBillingModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      {/* Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        user={user}
        isSimulating={isSimulating}
        onOpenVerifyModal={() => setIsVerifyModalOpen(true)}
        onOpenBillingModal={() => setIsBillingModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {currentTab === 'simulator' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
            {/* Live Telemetry View when running or just completed */}
            {(isSimulating || telemetry.elapsedSeconds > 0) && (
              <LiveTelemetryDashboard
                telemetry={telemetry}
                scenario={scenario}
                onKillSwitch={handleKillSwitch}
                onReset={handleResetSimulation}
              />
            )}

            {/* Scenario Configuration & Builder */}
            <ScenarioBuilder
              scenario={scenario}
              onChangeScenario={setScenario}
              onLaunch={handleLaunchSimulation}
              isSimulating={isSimulating}
              domainVerified={domainVerified}
              onOpenVerifyModal={() => setIsVerifyModalOpen(true)}
            />
          </div>
        )}

        {currentTab === 'architecture' && <ArchitectureViewer />}
        {currentTab === 'database' && <DatabaseSchemaExplorer />}
        {currentTab === 'worker-code' && <WorkerCodeInspector />}
        {currentTab === 'api-swagger' && <ApiConsole />}
        {currentTab === 'security' && <SecurityRoadmap />}
      </main>

      {/* Modals */}
      <DomainVerificationModal
        isOpen={isVerifyModalOpen}
        onClose={() => setIsVerifyModalOpen(false)}
        domain={scenario.targetUrl}
        isVerified={domainVerified}
        onVerifySuccess={() => {
          setDomainVerified(true);
          setIsVerifyModalOpen(false);
        }}
      />

      <BillingCalculatorModal
        isOpen={isBillingModalOpen}
        onClose={() => setIsBillingModalOpen(false)}
        currentTier={user.tier}
        creditsRemaining={user.creditsRemaining}
        onSelectTier={handleSelectTier}
      />
    </div>
  );
}
