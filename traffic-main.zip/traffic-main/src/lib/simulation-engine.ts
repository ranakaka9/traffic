/**
 * Pure simulation logic for AetherLoad Global Synthetic Traffic & Load Engine.
 * Decoupled from React UI for fast deterministic testing and production execution.
 */

export interface DeviceProfile {
  id: string;
  name: string;
  category: 'desktop' | 'mobile' | 'tablet';
  os: 'Windows 11' | 'Windows 10' | 'iOS 18' | 'iOS 17' | 'Android 15' | 'iPadOS 18';
  browser: 'Chrome 128' | 'Edge 128' | 'Firefox 130' | 'Safari 18' | 'Samsung Internet 25';
  viewport: { width: number; height: number; dpr: number };
  touch: boolean;
  userAgent: string;
  clientHints: {
    mobile: boolean;
    platform: string;
    brands: Array<{ brand: string; version: string }>;
  };
}

export type TrafficPattern = 'ramp' | 'steady' | 'spike' | 'step';

/**
 * Calculates the active virtual users (VUs) at a given elapsed second
 * based on the configured traffic ramp curve.
 */
export function calculateConcurrencyAtSecond(
  elapsedSeconds: number,
  totalDurationSeconds: number,
  peakConcurrency: number,
  pattern: TrafficPattern
): number {
  if (elapsedSeconds <= 0) return 0;
  if (elapsedSeconds >= totalDurationSeconds) return 0;

  const progress = elapsedSeconds / totalDurationSeconds;

  switch (pattern) {
    case 'steady': {
      // 5% ramp-up, 90% steady, 5% ramp-down
      if (progress < 0.05) {
        return Math.max(1, Math.round((progress / 0.05) * peakConcurrency));
      } else if (progress > 0.95) {
        return Math.max(1, Math.round(((1 - progress) / 0.05) * peakConcurrency));
      }
      return peakConcurrency;
    }

    case 'ramp': {
      // 30% linear ramp-up, 40% steady peak, 30% ramp-down
      if (progress < 0.3) {
        return Math.max(1, Math.round((progress / 0.3) * peakConcurrency));
      } else if (progress < 0.7) {
        return peakConcurrency;
      } else {
        return Math.max(1, Math.round(((1 - progress) / 0.3) * peakConcurrency));
      }
    }

    case 'spike': {
      // Baseline 10%, violent spike to 100% at 40%-60%, return to 10%
      const baseline = Math.max(1, Math.round(peakConcurrency * 0.1));
      if (progress >= 0.35 && progress <= 0.65) {
        // Bell spike
        const spikeFactor = Math.sin(((progress - 0.35) / 0.3) * Math.PI);
        return Math.round(baseline + (peakConcurrency - baseline) * spikeFactor);
      }
      return baseline;
    }

    case 'step': {
      // 4 discrete stairs (25%, 50%, 75%, 100%)
      if (progress < 0.25) return Math.max(1, Math.round(peakConcurrency * 0.25));
      if (progress < 0.5) return Math.max(1, Math.round(peakConcurrency * 0.5));
      if (progress < 0.75) return Math.max(1, Math.round(peakConcurrency * 0.75));
      return peakConcurrency;
    }

    default:
      return peakConcurrency;
  }
}

/**
 * Generates exact HTTP request headers matching a target device profile,
 * including modern Client Hints (Sec-CH-UA) to bypass anti-bot and CDN bot mitigations.
 */
export function generateDeviceHeaders(profile: DeviceProfile): Record<string, string> {
  const brandStrings = profile.clientHints.brands
    .map((b) => `"${b.brand}";v="${b.version}"`)
    .join(', ');

  const headers: Record<string, string> = {
    'User-Agent': profile.userAgent,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-CH-UA': brandStrings,
    'Sec-CH-UA-Mobile': profile.clientHints.mobile ? '?1' : '?0',
    'Sec-CH-UA-Platform': `"${profile.clientHints.platform}"`,
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
  };

  if (profile.category === 'mobile') {
    headers['Viewport-Width'] = `${profile.viewport.width}`;
    headers['DPR'] = `${profile.viewport.dpr}`;
  }

  return headers;
}

/**
 * Validates domain ownership via DNS TXT record or HTML meta tag token.
 */
export function verifyDomainRecord(
  targetDomain: string,
  expectedToken: string,
  records: string[]
): { verified: boolean; message: string } {
  if (!targetDomain || targetDomain.trim() === '') {
    return { verified: false, message: 'Target domain cannot be empty.' };
  }

  const prefix = 'aetherload-verification=';
  const fullExpected = expectedToken.startsWith(prefix) ? expectedToken : `${prefix}${expectedToken}`;

  const match = records.find(
    (record) => record.trim() === fullExpected || record.trim().replace(/^"|"$/g, '') === fullExpected
  );

  if (match) {
    return {
      verified: true,
      message: `Domain ${targetDomain} verified successfully via token ${fullExpected}`,
    };
  }

  return {
    verified: false,
    message: `Verification token ${fullExpected} not found in ${records.length} published record(s).`,
  };
}

/**
 * Lightweight robots.txt parser ensuring compliance with user agent allow/disallow rules.
 */
export function parseRobotsTxt(
  content: string,
  targetUserAgent: string = 'AetherLoadBot'
): {
  disallowedPaths: string[];
  crawlDelaySeconds: number | null;
  isAllowed: (path: string) => boolean;
} {
  const lines = content.split('\n').map((l) => l.trim());
  const disallowed: string[] = [];
  let crawlDelay: number | null = null;
  let activeForUs = false;

  for (const rawLine of lines) {
    const line = rawLine.replace(/#.*$/, '').trim();
    if (!line) continue;

    const lower = line.toLowerCase();
    if (lower.startsWith('user-agent:')) {
      const agent = line.substring(11).trim();
      activeForUs = agent === '*' || agent.toLowerCase() === targetUserAgent.toLowerCase();
    } else if (activeForUs) {
      if (lower.startsWith('disallow:')) {
        const path = line.substring(9).trim();
        if (path) disallowed.push(path);
      } else if (lower.startsWith('crawl-delay:')) {
        const parsed = parseFloat(line.substring(12).trim());
        if (!isNaN(parsed)) crawlDelay = parsed;
      }
    }
  }

  return {
    disallowedPaths: disallowed,
    crawlDelaySeconds: crawlDelay,
    isAllowed: (path: string) => {
      for (const dis of disallowed) {
        if (dis === '/' || path.startsWith(dis)) {
          return false;
        }
      }
      return true;
    },
  };
}

/**
 * SaaS Usage metering and credit deduction calculation.
 * Free tier: Datacenter only, up to 50 VUs.
 * Pro tier: Residential proxies ($0.05 / VU-hour equiv), full headless browser compute.
 */
export function calculateUsageCredits(params: {
  durationSeconds: number;
  peakConcurrency: number;
  proxyTier: 'datacenter' | 'residential' | 'mobile';
  workerType: 'go_http' | 'playwright_browser';
}): { creditsDeducted: number; estimatedCostUsd: number } {
  const durationHours = params.durationSeconds / 3600;
  const vuHours = params.peakConcurrency * durationHours;

  // Compute weight: Browser full DOM takes 4x compute of Go HTTP
  const computeMultiplier = params.workerType === 'playwright_browser' ? 4 : 1;

  // Proxy network weight: Residential is 3x, Mobile 5G is 6x datacenter
  const proxyMultiplier =
    params.proxyTier === 'mobile' ? 6 : params.proxyTier === 'residential' ? 3 : 1;

  // 1 credit = 10 VU-seconds of baseline HTTP datacenter
  const rawCredits = Math.ceil(
    (params.peakConcurrency * params.durationSeconds * computeMultiplier * proxyMultiplier) / 10
  );

  // $0.001 per 10 credits (~$0.10 per 1,000 credits)
  const estimatedCost = Number(((rawCredits / 1000) * 0.1).toFixed(4));

  return {
    creditsDeducted: Math.max(1, rawCredits),
    estimatedCostUsd: Math.max(0.01, estimatedCost),
  };
}
