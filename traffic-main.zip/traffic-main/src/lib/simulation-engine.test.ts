import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateConcurrencyAtSecond,
  generateDeviceHeaders,
  verifyDomainRecord,
  parseRobotsTxt,
  calculateUsageCredits,
  DeviceProfile,
} from './simulation-engine';

test('concurrency curve ramp starts at low VU and peaks at center', () => {
  const total = 100;
  const peak = 500;

  // At start (0 seconds)
  const start = calculateConcurrencyAtSecond(0, total, peak, 'ramp');
  assert.equal(start, 0);

  // At 15 seconds (ramp up phase halfway to 30%)
  const midwayRamp = calculateConcurrencyAtSecond(15, total, peak, 'ramp');
  assert.equal(midwayRamp, 250);

  // At 50 seconds (peak phase)
  const steady = calculateConcurrencyAtSecond(50, total, peak, 'ramp');
  assert.equal(steady, 500);

  // At 85 seconds (ramp down phase)
  const rampDown = calculateConcurrencyAtSecond(85, total, peak, 'ramp');
  assert.equal(rampDown, 250);

  // Out of bounds
  assert.equal(calculateConcurrencyAtSecond(100, total, peak, 'ramp'), 0);
  assert.equal(calculateConcurrencyAtSecond(-5, total, peak, 'ramp'), 0);
});

test('concurrency curve spike behavior', () => {
  const total = 100;
  const peak = 1000;

  // Baseline at start
  const baseline = calculateConcurrencyAtSecond(10, total, peak, 'spike');
  assert.equal(baseline, 100);

  // Peak at 50%
  const spikePeak = calculateConcurrencyAtSecond(50, total, peak, 'spike');
  assert.equal(spikePeak, 1000);
});

test('device headers generation includes sec-ch-ua and platform', () => {
  const profile: DeviceProfile = {
    id: 'win11-chrome',
    name: 'Windows 11 Chrome',
    category: 'desktop',
    os: 'Windows 11',
    browser: 'Chrome 128',
    viewport: { width: 1920, height: 1080, dpr: 1 },
    touch: false,
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    clientHints: {
      mobile: false,
      platform: 'Windows',
      brands: [
        { brand: 'Chromium', version: '128' },
        { brand: 'Google Chrome', version: '128' },
      ],
    },
  };

  const headers = generateDeviceHeaders(profile);
  assert.equal(headers['User-Agent'], profile.userAgent);
  assert.equal(headers['Sec-CH-UA-Platform'], '"Windows"');
  assert.equal(headers['Sec-CH-UA-Mobile'], '?0');
  assert.match(headers['Sec-CH-UA'], /Google Chrome/);
});

test('domain verification checks DNS TXT record matching', () => {
  const domain = 'example.com';
  const token = 'token_abc123';
  const records = ['v=spf1 include:_spf.google.com ~all', 'aetherload-verification=token_abc123'];

  const result = verifyDomainRecord(domain, token, records);
  assert.equal(result.verified, true);

  const failed = verifyDomainRecord(domain, 'token_xyz999', records);
  assert.equal(failed.verified, false);
});

test('robots.txt parser honors Disallow and Crawl-delay', () => {
  const txt = `
    User-agent: *
    Disallow: /admin
    Disallow: /internal/api
    Crawl-delay: 2

    User-agent: BadBot
    Disallow: /
  `;

  const parsed = parseRobotsTxt(txt, 'AetherLoadBot');
  assert.equal(parsed.crawlDelaySeconds, 2);
  assert.equal(parsed.isAllowed('/public/store'), true);
  assert.equal(parsed.isAllowed('/admin/users'), false);
  assert.equal(parsed.isAllowed('/internal/api/v1'), false);
});

test('calculateUsageCredits scales by worker type and proxy tier', () => {
  // Datacenter HTTP worker for 60s at 100 VUs: (100 * 60 * 1 * 1) / 10 = 600 credits
  const base = calculateUsageCredits({
    durationSeconds: 60,
    peakConcurrency: 100,
    proxyTier: 'datacenter',
    workerType: 'go_http',
  });
  assert.equal(base.creditsDeducted, 600);

  // Residential Playwright browser worker (4x compute * 3x proxy = 12x): 600 * 12 = 7,200 credits
  const heavy = calculateUsageCredits({
    durationSeconds: 60,
    peakConcurrency: 100,
    proxyTier: 'residential',
    workerType: 'playwright_browser',
  });
  assert.equal(heavy.creditsDeducted, 7200);
});
